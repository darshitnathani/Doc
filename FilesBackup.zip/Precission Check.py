# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:32:56 2017

@author: dnathani
"""
import numpy as np
from sklearn.metrics import precision_recall_fscore_support


y_true = np.array(['cat', 'dog', 'pig', 'cat', 'dog', 'pig'])
y_pred = np.array(['cat', 'pig', 'dog', 'cat', 'cat', 'dog'])
print(y_true)
print(precision_recall_fscore_support(y_true, y_pred, average='macro'))


print(precision_recall_fscore_support(y_true, y_pred, average='micro'))


print(precision_recall_fscore_support(y_true, y_pred, average='weighted'))