# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 12:15:10 2017

@author: dnathani
"""

# Recursive Feature Elimination
from sklearn import datasets
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression


def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("creditcard.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,30):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[30].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    
    return Result

creditCard=dataSetNo1()

TData=[]
RData=[]

for data in creditCard:
    TData.append(data[0])
    RData.append(data[1])

# load the iris datasets
dataset = datasets.load_iris()
# create a base classifier used to evaluate a subset of attributes
model = LogisticRegression()
# create the RFE model and select 3 attributes
rfe = RFE(model, 3)
rfe = rfe.fit(TData, RData)
# summarize the selection of the attributes
storeValidity=rfe.support_
storeRank=rfe.ranking_
print(rfe.support_)
print(rfe.ranking_)