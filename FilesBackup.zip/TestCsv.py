# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 16:46:00 2017

@author: dnathani
"""
import csv
import os
import numpy as np


Training=60
Testing=20
Hold=20
    
print(Training,Testing,Hold)



#filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","IrisData2.csv")

filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","creditcard.csv")

with open(filepath,"r") as f:
        reader = csv.reader(f,delimiter = ",")
        columns=reader.next()
        print(columns)
        data = list(reader)
        row_count = len(data)
        trainEnd=int(((row_count*Training)+1)/100)
        testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
        randomList=np.random.randint(1,row_count,size=row_count)
        trainingData=[]
        testingData=[]
        for data in range(0,trainEnd):
            trainingData.append(randomList[data])
        for data in range(trainEnd,testEnd):
            testingData.append(randomList[data])
            
        print(len(trainingData),len(testingData))
  
with open(filepath,"r") as f:
        rowsData=[]
        reader = csv.reader(f,delimiter = ",")
        for row in reader:
            rowsData.append(row)
           
        Training_data=[]
        Testing_data=[]
        
        for data in trainingData:
            Training_data.append(rowsData[data])
            
        
        for data in testingData:
            Testing_data.append(rowsData[data])
        
        TrainingDataResult=[]
        TrainingInputData=[]
        for newLine in Training_data:
                temp=[]
                temp2=[]
                for dataindex in range(0,(len(columns)-1)):
                    temp2.append(float(newLine[dataindex]))
                TrainingDataResult.append(int(newLine[len(columns)-1]))
                TrainingInputData.append(temp2)
                
                
        TestingDataResult=[]
        TestingInputData=[]
        for newLine in Testing_data:
                temp=[]
                temp2=[]
                for dataindex in range(0,(len(columns)-1)):
                    temp2.append(float(newLine[dataindex]))
                TestingDataResult.append(int(newLine[len(columns)-1]))
                TestingInputData.append(temp2)
                
                