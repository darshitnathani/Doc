# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 11:47:27 2017

@author: dnathani
"""

# Feature Extraction with Univariate Statistical Tests (Chi-squared for classification)
import pandas
import numpy
from sklearn.feature_selection import RFE
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn import datasets
from sklearn import metrics
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.decomposition import PCA

dataset = datasets.load_iris()
test = SelectKBest(score_func=chi2, k=4)
fit = test.fit(dataset.data, dataset.target)
# summarize scores
numpy.set_printoptions(precision=4)
print("**************Chi-squared************")
print(fit.scores_)
features = fit.transform(dataset.data)

model = LogisticRegression()
rfe = RFE(model, 1)
fit = rfe.fit(dataset.data, dataset.target)
print("*******************RFE****************")
print("Num Features: %d") % fit.n_features_
print("Selected Features: %s") % fit.support_
print("Feature Ranking: %s") % fit.ranking_
print("*******************feature_importances****************")
model = ExtraTreesClassifier()
model.fit(dataset.data, dataset.target)
print(model.feature_importances_)
print("*******************PCA****************")
pca = PCA(n_components=4)
fit = pca.fit(dataset.data)
print("Explained Variance: %s") % fit.explained_variance_ratio_

'''
3 4 1 2
4 2 3 1
3 4 2 1
4 3 2 1
'''