# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 21:20:26 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug 08 17:39:06 2017

@author: dnathani
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
import seaborn as sns

data = pd.read_csv("IrisData2.csv")
print(data.head())

v_features = data.ix[:,0:4].columns
plt.figure(figsize=(12,28*4))
gs = gridspec.GridSpec(28, 1)
for i, cn in enumerate(data[v_features]):
    print(cn)
    ax = plt.subplot(gs[i])
    sns.distplot(data[cn][data['Numeric Value'] == 0], bins=50)
    sns.distplot(data[cn][data['Numeric Value'] == 1], bins=50)
    sns.distplot(data[cn][data['Numeric Value'] == 2], bins=50)
    ax.set_xlabel('')
    ax.set_title('histogram of feature: ' + str(cn))
plt.show()