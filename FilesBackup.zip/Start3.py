# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 17:35:12 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 16:51:50 2017

@author: dnathani
"""
from sklearn.tree import DecisionTreeClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D



def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("IrisData.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            temp2.append(float(newLine[0]))
            temp2.append(float(newLine[1]))
            temp2.append(float(newLine[2]))
            temp2.append(float(newLine[3]))
            temp=newLine[5].split("\n")
            dataResult.append(float(temp[0]))
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    print(Result)
    return Result


irisData=dataSetNo1()

TData=[]
RData=[]

for data in irisData:
    TData.append(data[0])
    RData.append(data[1])
print(TData)
print(RData)

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]

for data in TData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])
    
trainer=DecisionTreeClassifier()

trainer=trainer.fit(TData,RData)

print(trainer.predict([5.1, 3.5, 1.4, 0.2]))

print(trainer.predict([5.9, 3.0, 5.1, 1.8]))

dataTest=trainer.predict([5.1, 3.5, 1.4, 0.2])


if(dataTest==0):
    print("Selected Flower is setosa")
elif(dataTest==1):
    print("Selected Flower is versicolor")
else:
    print("Selected Flower is virginica")
plt.figure(num=1)
plt.scatter(trainingDataX, trainingDataY,c=RData)
plt.figure(num=2)
plt.scatter(trainingDataP, trainingDataQ,c=RData)
plt.figure(num=3)
plt.scatter(trainingDataY, trainingDataP,c=RData)
plt.figure(num=4)
plt.scatter(trainingDataX, trainingDataQ,c=RData)
plt.figure(num=5)
plt.scatter(trainingDataX, trainingDataP,c=RData)
plt.figure(num=6)
plt.scatter(trainingDataY, trainingDataQ,c=RData)
