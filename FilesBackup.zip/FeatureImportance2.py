# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 11:07:36 2017

@author: dnathani
"""

import numpy as np    
from sklearn.linear_model import LogisticRegression
from sklearn import datasets
from sklearn import metrics
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier

dataset = datasets.load_iris()

m = LogisticRegression()
m.fit(dataset.data, dataset.target)
print(m._estimator_type)
# The estimated coefficients will all be around 1:
print(m.coef_)

# Those values, however, will show that the second parameter
# is more influential
print(np.std(X, 0)*m.coef_)
#An alternative way to get a similar result is to examine the coefficients of the model fit on standardized parameters:

m.fit(X / np.std(X, 0), y)
print(m.coef_)