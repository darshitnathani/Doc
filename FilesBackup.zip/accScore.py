# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 16:49:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 17:35:12 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 16:51:50 2017

@author: dnathani
"""
from sklearn import tree
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from subprocess import check_call
import pydot
from sklearn.cross_validation import cross_val_score 
from sklearn.neighbors import KNeighborsClassifier

def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("IrisData.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            temp2.append(float(newLine[0]))
            temp2.append(float(newLine[1]))
            temp2.append(float(newLine[2]))
            temp2.append(float(newLine[3]))
            temp=newLine[5].split("\n")
            dataResult.append(float(temp[0]))
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    print(Result)
    return Result


irisData=dataSetNo1()

print(irisData)

TData=[]
RData=[]

for data in irisData:
    TData.append(data[0])
    RData.append(data[1])
print(TData)
print(RData)

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]

for data in TData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])

knn = KNeighborsClassifier(n_neighbors=5)
scores = cross_val_score(knn, TData, RData, cv=10, scoring='accuracy')
print(scores)  

k_range = list(range(1, 31))
k_scores = []
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, TData, RData, cv=10, scoring='accuracy')
    k_scores.append(scores.mean())
print(k_scores) 