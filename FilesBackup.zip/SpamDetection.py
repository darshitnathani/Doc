# -*- coding: utf-8 -*-
"""
Created on Thu Aug 03 19:16:16 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug 03 13:13:04 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug 01 17:58:14 2017

@author: dnathani
"""

from Tkinter import StringVar
from Tkinter import Tk
from Tkinter import Label
from Tkinter import OptionMenu
from Tkinter import Button
import tkMessageBox
from sklearn.tree import DecisionTreeClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.decomposition import PCA

def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("spambaseDataset.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,57):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[57].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    print(Result)
    return Result


irisData=dataSetNo1()

TData=[]
RData=[]

for data in irisData:
    TData.append(data[0])
    RData.append(data[1])
print(TData)
print(RData)

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]
trainingDataU=[]
trainingDataV=[]


trainingDataX1=[]
trainingDataY1=[]
trainingDataP1=[]
trainingDataQ1=[]
trainingDataU1=[]
trainingDataV1=[]

for data in TData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])
    trainingDataU.append(data[4])
    trainingDataV.append(data[5])
    
    trainingDataX1.append(float(data[0])/4)
    trainingDataY1.append(float(data[1])/4)
    trainingDataP1.append(float(data[2])/5)
    trainingDataQ1.append(float(data[3])/7)
    trainingDataU1.append(float(data[4])/3)
    trainingDataV1.append(float(data[5])/3)


trainer=DecisionTreeClassifier()


trainer=trainer.fit(TData,RData)



root = Tk()
root.title("Test How good is your Car...")

var1 = StringVar(root)
var1.set("Buying Price ?")
var2 = StringVar(root)
var2.set("Maintenance Price ?")
var3 = StringVar(root)
var3.set("Number of doors?")
var4 = StringVar(root)
var4.set("Number of persons it can take?")
var5 = StringVar(root)
var5.set("luggage boot size?")
var6 = StringVar(root)
var6.set("How much safe it is?")
data=[]
count1=0
count2=0
count3=0
count4=0
count5=0
count6=0


def grab_and_assign1(event):
    chosen_option1 = var1.get()
    label_chosen_variable= Label(root, text=chosen_option1)
    label_chosen_variable.grid(row=1, column=2)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=0)
    print chosen_option1
    
def grab_and_assign2(event):
    chosen_option2 = var2.get()
    label_chosen_variable= Label(root, text=chosen_option2)
    label_chosen_variable.grid(row=1, column=5)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=3)
    print chosen_option2
    
def grab_and_assign3(event):
    chosen_option3 = var3.get()
    label_chosen_variable= Label(root, text=chosen_option3)
    label_chosen_variable.grid(row=1, column=8)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=6)
    print chosen_option3
    
def grab_and_assign4(event):
    chosen_option4 = var4.get()
    label_chosen_variable= Label(root, text=chosen_option4)
    label_chosen_variable.grid(row=1, column=11)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=9)
    print chosen_option4
    
def grab_and_assign5(event):
    chosen_option5 = var5.get()
    label_chosen_variable= Label(root, text=chosen_option5)
    label_chosen_variable.grid(row=1, column=14)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=12)
    print chosen_option5
    
def grab_and_assign6(event):
    chosen_option6 = var6.get()
    label_chosen_variable= Label(root, text=chosen_option6)
    label_chosen_variable.grid(row=1, column=17)
    label_left=Label(root, text="You have Chosen= ")
    label_left.grid(row=1, column=15)
    print chosen_option6
    

def helloCallBack():
   dataResult=trainer.predict([0.27,0.05,0.1,0,0,0,0,0,0,0,0,0.48,0,0,0,0,0,0.1,0.97,0,0.1,3.47,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.27,0,0,0,0,0,0,0,0,0.76,0,0,0.607,0.064,0.036,0.055,0,0.202,3.766,43,1789])
   tkMessageBox.showinfo( "Result",dataResult)
#   if dataResult==1:
#        tkMessageBox.showinfo( "Result","Your car is Un acceptable")
#   elif dataResult==2:
#        tkMessageBox.showinfo( "Result","Your car is acceptable")
#   elif dataResult==3:
#        tkMessageBox.showinfo( "Result","Your car is Good")
#   else:
#        tkMessageBox.showinfo( "Result","Your car is Very Good")
   
   

drop_menu = OptionMenu(root, var1,  "vhigh", "high", "med", "low", command=grab_and_assign1)
drop_menu.grid(row=0, column=0)
drop_menu = OptionMenu(root, var2,  "vhigh", "high", "med", "low", command=grab_and_assign2)
drop_menu.grid(row=0, column=3)
drop_menu = OptionMenu(root, var3,  "2", "3", "4", "others", command=grab_and_assign3)
drop_menu.grid(row=0, column=6)
drop_menu = OptionMenu(root, var4,  "2", "4", "others", command=grab_and_assign4)
drop_menu.grid(row=0, column=9)
drop_menu = OptionMenu(root, var5,  "small", "med", "large", command=grab_and_assign5)
drop_menu.grid(row=0, column=12)
drop_menu = OptionMenu(root, var6,  "low", "med", "high", command=grab_and_assign6)
drop_menu.grid(row=0, column=15)

drop_menu=Button(root, text ="Submit", command = helloCallBack )
drop_menu.grid(row=2, column=8)
root.mainloop()



print(trainer.predict([buyingPriceFormating(var1.get()),maintenancepriceFormating(var2.get()),doorsFormating(var3.get()),personsFormating(var4.get()),lugBootFormating(var5.get()),safetyFormating(var6.get())]))

print(trainer.predict([4,4,5,7,3,3]))

#print(trainer.predict([5.9, 3.0, 5.1, 1.8]))

#dataTest=trainer.predict([5.1, 3.5, 1.4, 0.2])

#
#if(dataTest==0):
#    print("Selected Flower is setosa")
#elif(dataTest==1):
#    print("Selected Flower is versicolor")
#else:
#    print("Selected Flower is virginica")
plt.figure(num=1)
plt.scatter(trainingDataX, trainingDataY,c=RData)
plt.figure(num=2)
plt.scatter(trainingDataP, trainingDataQ,c=RData)
plt.figure(num=3)
plt.scatter(trainingDataU, trainingDataV,c=RData)


plt.figure(num=4)
plt.scatter(trainingDataY, trainingDataP,c=RData)
plt.figure(num=5)
plt.scatter(trainingDataQ, trainingDataU,c=RData)
plt.figure(num=6)
plt.scatter(trainingDataV, trainingDataX,c=RData)

#
#fig = plt.figure(7, figsize=(8, 6))
#ax = Axes3D(fig, elev=-150, azim=110)
#X_reduced = PCA(n_components=3).fit_transform(TData)
#print("***************************************************************************")
#print(X_reduced)
#print("***************************************************************************")
#X_reduced_new=[]
#
#for data in X_reduced:
#    X_reduced_new.append(data)
#
#ax.scatter(X_reduced_new[:, 1], X_reduced_new[:, 2], X_reduced_new[:, 3], c=RData,
#           cmap=plt.cm.Paired)
#ax.set_title("First three PCA directions")
#ax.set_xlabel("1st eigenvector")
#ax.w_xaxis.set_ticklabels([])
#ax.set_ylabel("2nd eigenvector")
#ax.w_yaxis.set_ticklabels([])
#ax.set_zlabel("3rd eigenvector")
#ax.w_zaxis.set_ticklabels([])