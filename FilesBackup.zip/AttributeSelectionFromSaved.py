# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 10:12:40 2017

@author: dnathani
"""
import pickle
    


filename = 'CreditCardModleDTREF.sav'
loaded_model_REF = pickle.load(open(filename, 'rb'))

#rfe = RFE(loaded_model, 3)
#rfe = rfe.fit(TestTData, TestRData)
storeValidity=loaded_model_REF.support_
storeRank=loaded_model_REF.ranking_
print(loaded_model_REF.support_)
print(loaded_model_REF.ranking_)