# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 11:52:26 2017

@author: dnathani
"""

import pandas as pd

data = pd.read_csv("creditcard - Copy.csv", sep = ",")
data.head()
print(data.describe())
summary = data.describe()
print(summary)
summary = summary.transpose()
print(summary)

