# -*- coding: utf-8 -*-
"""
Created on Thu Sep 14 10:55:33 2017

@author: dnathani
"""

import flask
from flask import session
from flask import request
import os
from flask import Flask
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import pickle
import json
import csv
import random


###############################################################################
#Configuration
###############################################################################
def dataSetNo1():
    try:
        inputData=[]
        dataResult=[]
        fobj=open("creditcard.csv","r")
        #fobj=open("creditcard - Copy.csv","r")              
        
        count=0
        index=0
        for line in fobj:
            newLine=line.split(",")
            
            if index!=0:
                temp=[]
                temp2=[]
                for dataindex in range(0,30):
                    try:
                        temp2.append(float(newLine[dataindex]))
                    except Exception as err:
                        print(count)
                        print(err,newLine[dataindex])
                        print(err,dataindex)
                temp=newLine[30].split("\n")
                dataResult.append(temp[0])
                inputData.append(temp2)
                count=count+1
            index=index+1  
    
        
        fobj.close()
        Result=zip(inputData,dataResult)
     
        return Result
    except Exception as err:
        print(err,newLine[dataindex])
        print(err,dataindex)

class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"

###############################################################################
#Flask Configuration
###############################################################################
        
#        
app = Flask(__name__, static_url_path="", static_folder="static")
app.secret_key = os.urandom(24)

#sess = session.Session()
#sess.init_app(app)
###############################################################################
#Variables
###############################################################################
@app.route('/test')
def attribute_selectionOuter(self):
    dataImp=Implement()
    return dataImp.attribute_selection()

class Implement():
    
    @app.route("/Hello")
    def HelloWorld(self):
        return "Hey How are you world"
        
    
    @app.route('/test')
    def attribute_selection(self):
        session['darshitArray']=[1,2,3]
        return "OK"
    
    @app.route('/test2/<Data>')
    def attribute_selection1(self,Data):
        session['darshitVariable'] = Data
        session['darshitArray'].append(5)
        #creditCard=dataSetNo1()
        return session['darshitVariable']
    
    @app.route('/save')    
    def rename_savedfile(self):
        user=request.args.get('modelName')
        session[user]={}
        session[user]["data"]= request.args.get('data')
        return "Done"
    
    @app.route('/test/getData')
    def GetData():
        print(session['darshitArray'])
        return session['darshitVariable']
    
    @app.route('/save/test')
    def GetData2():
        user=request.args.get('modelName')
        print(session['darshitVariableData'])
        return session['darshitVariableData']
    
    @app.route('/save/test2')
    def GetData3():
        user=request.args.get('modelName')
        print(session[user]['data'])
        return session[user]['data']
    
    @app.route('/logout')
    def logout():
        session.pop(request.args.get('modelName'), None)
        return "Succesful Logout"


if __name__ == '__main__':
    app = Flask(__name__, static_url_path="", static_folder="static")
    app.secret_key = os.urandom(24)
    configuration = Configuration()
    configuration.proxies()
    app.run('0.0.0.0',2507)
