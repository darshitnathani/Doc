# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 14:39:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 14:49:47 2017

@author: dnathani
"""

import flask
from flask import request
import os
from flask import Flask
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
import seaborn as sns
from Tkinter import StringVar
from Tkinter import Tk
from Tkinter import Label
from Tkinter import OptionMenu
from Tkinter import Button
import tkMessageBox
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
import pickle
import json
import csv


def dataSetTest(filename):

    inputData=[]
    dataResult=[]
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials\PYUI\templates\Uploads",filename)
    print(filepath)
    fobj=open(filepath,"r")           
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,30):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[30].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    
    return Result



trainer = pickle.load(open("../CreditCardModleDT.sav", 'rb'))
trainer2 = pickle.load(open("../CreditCardModleKNN.sav", 'rb'))

app = Flask(__name__, static_url_path="", static_folder="static")

Training=50
Testing=50
Hold=0

@app.route('/splitData', methods=['POST'])    
def predict_formData():
    input_json = request.get_json(force=True)  
    print(input_json)
    Training=input_json["Training"]
    Testing=input_json["Testing"]
    Hold=input_json["Hold"]
    
    print(Training,Testing,Hold)
    return "Data Splited Succesfully"

def split_Data():
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials\PYUI\templates\Uploads","creditcardTest - Copy (2).csv")
    print(filepath)    
    with open(filepath,"r") as f:
        reader = csv.reader(f,delimiter = ",")
        data = list(reader)
        row_count = len(data)
    print(row_count)
    
@app.route('/accTest/<filename>')    
def trained_test(filename):
    
    testData=dataSetTest(filename)
    TestTData=[]
    TestRData=[]
    
    for data in testData:
        TestTData.append(data[0])
        TestRData.append(data[1])
        
    prediction=trainer.predict(TestTData)
    acc1=accuracy_score(TestRData,prediction)
    
    prediction2=trainer2.predict(TestTData)
    acc2=accuracy_score(TestRData,prediction2)
    
    
    print(acc1*100)
    print(acc2*100)
    result={"Modle1Acc": acc1*100, "Modle2Acc": acc2*100}
    return json.dumps(result)
    

@app.route('/predict')    
def prredict_result():
    
    testData=dataSetTest()
    TestTData=[]
    TestRData=[]
    
    for data in testData:
        TestTData.append(data[0])
        TestRData.append(data[1])
        
    prediction=""
    print(prediction)
    
    prediction2=trainer2.predict(TestTData)
    acc2=accuracy_score(TestRData,prediction2)
    
    return "TODO"


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"



@app.route('/')
def hello_world():
    #return flask.render_template('index.html')
    return "ML.html"

@app.route('/machineLearning')
def machine_learning():
    return flask.render_template('ML.html')

if __name__ == '__main__':
    configuration = Configuration()
    configuration.proxies()
    app.run('0.0.0.0',1612)