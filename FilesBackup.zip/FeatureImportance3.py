# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 11:11:22 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 22:32:12 2017

@author: darshit.nj
"""

# Feature Importance
from sklearn import datasets
from sklearn import metrics
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
# load the iris datasets
dataset = datasets.load_iris()
# fit an Extra Trees model to the data
model = DecisionTreeClassifier()
data=model.fit(dataset.data, dataset.target)
print(data.score)
# display the relative importance of each attribute
print(model.feature_importances_)
feature_importance = model.feature_importances_
feature_importance = 100.0 * (feature_importance / feature_importance.max())
print(feature_importance)