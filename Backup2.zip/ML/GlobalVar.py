# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 11:47:15 2017

@author: dnathani
"""

x=["Darshit"]
y=10
z=[1,2,3]
def add_values():
    x.append("Jayesh")
    global y
    global z
    z=[2,3,4,5]
    y=15
print(x)
print(y)

add_values()

print(x)
print(y)

print(z)    