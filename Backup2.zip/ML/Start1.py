# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 16:51:50 2017

@author: dnathani
"""
#
#import pandas
#from pandas.tools.plotting import scatter_matrix
#import matplotlib.pyplot as plt
#from sklearn import model_selection
#from sklearn.metrics import classification_report
#from sklearn.metrics import confusion_matrix
#from sklearn.metrics import accuracy_score
#from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
#from sklearn.neighbors import KNeighborsClassifier
#from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
#from sklearn.naive_bayes import GaussianNB
#from sklearn.svm import SVC
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

dataset=datasets.load_iris()

trainingData= dataset.data

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]

for data in trainingData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])
    

print(trainingData)

trainingResult=dataset.target
print(trainingResult)
iris = datasets.load_iris()

digits = datasets.load_digits()

traningFormat=[]

for data in trainingData:
    temp=[]
    for data1 in data:
        temp.append(data1)
        
    traningFormat.append(temp)
resultFormat=[]

for data in trainingResult:
    resultFormat.append(data)
     

trainer=DecisionTreeClassifier()

trainer=trainer.fit(traningFormat,resultFormat)

print(trainer.predict([5.1, 3.5, 1.4, 0.2]))

print(trainer.predict([5.9, 3.0, 5.1, 1.8]))

dataTest=trainer.predict([5.9, 3.0, 5.1, 1.8])


if(dataTest==0):
    print("Selected Flower is setosa")
elif(dataTest==1):
    print("Selected Flower is versicolor")
else:
    print("Selected Flower is virginica")
plt.figure(num=1)
plt.scatter(trainingDataX, trainingDataY,c=resultFormat)
plt.figure(num=2)
plt.scatter(trainingDataP, trainingDataQ,c=resultFormat)
plt.figure(num=3)
plt.scatter(trainingDataY, trainingDataP,c=resultFormat)
plt.figure(num=4)
plt.scatter(trainingDataX, trainingDataQ,c=resultFormat)
#plt.plot(trainingDataX,trainingDataY)