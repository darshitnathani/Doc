# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 15:13:22 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 11:58:02 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 14:39:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 14:49:47 2017

@author: dnathani
"""

from flask import request
import os
from flask import session
from flask import Flask
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_recall_fscore_support
import pandas as pd
import pickle
import json
import csv
import random


###############################################################################
#Configuration
###############################################################################


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"

###############################################################################
#Flask Configuration
###############################################################################
        
        
app = Flask(__name__, static_url_path="", static_folder="static")
app.secret_key = os.urandom(24)

###############################################################################
#Global Variables
###############################################################################
def reset_Data():
    session['columns']=[]
    session['rowsData']=[]
    session['FileData']=[]
    session['FileResult']=[]
    session['attributeValidity']=[]
    session['rowNumber']=0
    session['FileName']=""
    session['Training_data']=[]
    session['Testing_data']=[]
    session['Training_Result']=[]
    session['Testing_Result']=[]
    session['Filtered_traning_data']=[]
    session['finalAttributes']=[]
    session['FinalAttributeCount']=0
    session['Filtered_testing_data']=[]
    session['DT_accuracy']=0
    session['KNN_accuracy']=0
    session['data_Faltu1']=[]
    session['data_Faltu2']=[]
    session['UniqueList']=[]
    
###############################################################################
#Training
###############################################################################
#******************************************************************************
#Attribute Selection (First Call)
#******************************************************************************

@app.route('/dataset/split')
def attribute_selection():
    reset_Data()
    session['Filename'] =  request.args.get('file') + ".csv"
    session['Training'] = int(request.args.get('Training'))
    session['Testing'] = int(request.args.get('Testing'))
    session['Hold'] = int(request.args.get('Hold'))
    return "STEP 1 Done"


@app.route('/dataset/getAttributes')
def getAttribute():
    print(session['username']['faltudata'])
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",session['Filename'])
    with open(filepath,"r") as f:
            reader = csv.reader(f,delimiter = ",")
            session['columns']=reader.next()
            for row in reader:
                session['rowsData'].append(row)
                session['rowNumber'] = session['rowNumber']+ 1
            for newLine in session['rowsData']:
                temp2=[]
                for dataindex in range(0,(len(session['columns'])-1)):
                    temp2.append(float(newLine[dataindex]))
                session['FileResult'].append(int(newLine[len(session['columns'])-1]))
                session['FileData'].append(temp2)
                
    model = LogisticRegression()
    rfe = RFE(model, int(len(session['columns'])*0.4))
    rfe = rfe.fit(session['FileData'], session['FileResult'])
    session['attributeValidity']=rfe.support_.tolist()
    return split_Data(session['Training'],session['Testing'],session['Hold'])



def split_Data(Training,Testing,Hold):
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",session['Filename'])
    with open(filepath,"r") as f:
            reader = csv.reader(f,delimiter = ",")
            session['columns']=reader.next()
            data = list(reader)
            row_count = len(data)
            trainEnd=int(((row_count*Training)+1)/100)
            testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
            randomList=random.sample(range(1,row_count), row_count-1)
            trainingData=[]
            testingData=[]
            for data in range(0,trainEnd):
                trainingData.append(randomList[data])
            for data in range(trainEnd+1,testEnd):
                testingData.append(randomList[data])
           
      
    with open(filepath,"r") as f:
            rowsData=[]
            reader = csv.reader(f,delimiter = ",")
            for row in reader:
                rowsData.append(row)
            
            for data in trainingData:
                session['Training_data'].append(session['FileData'][data])
                session['Training_Result'].append(session['FileResult'][data])
                
            for data in testingData:
                session['Testing_data'].append(session['FileData'][data])
                session['Testing_Result'].append(session['FileResult'][data])
            
            df = pd.read_csv(filepath)
            
            columnResults=[]
            for data in session['columns']:
                columnResults.append(df[data].values)
            
            new_col_result=[]
            for data in columnResults:
                temp=[]
                for data_inside in data:
                    temp.append(float(data_inside))
                new_col_result.append(temp)
                
            newAttributeValidity=session['attributeValidity']
            groupingData=range(0,len(session['columns'])-1)
            groupingData.append(0)
            uniqueData=set()
            for data in new_col_result[len(session['columns'])-1]:
                uniqueData.add(data)
            session['UniqueList']=list(uniqueData)
            
            
            group=[]
            for data in range(0,len(session['columns'])-1):
                group.append(zip(new_col_result[groupingData[data]],new_col_result[groupingData[data+1]]))
            colorData=[]
            for data in range(0,len(session['columns'])):
                tempColor=[]
                tempColor.append(int(random.random()*255))
                tempColor.append(int(random.random()*255))
                tempColor.append(int(random.random()*255))
                colorData.append(tempColor)    
            results=[]

            for columnIndex in range(0,len(session['columns'])-1):
                    tempJsonData=[]
                    colorCount=0
                    for classificationData in session['UniqueList']:
                        mesData=[]
                        for data in range(0,len(new_col_result[len(session['columns'])-1])):
                            if new_col_result[len(session['columns'])-1][data] == classificationData:
                                mesData.append(group[columnIndex][data])
                        tempColorData="rgba({}, {}, {}, .5)".format(colorData[colorCount][0],colorData[colorCount][1],colorData[colorCount][2])        
                        tempJsonData.append({"Classification":classificationData,"Measurment":mesData,"color":tempColorData})
                        colorCount += 1
                    results.append({"attributeName":session['columns'][columnIndex],"attributeData":tempJsonData,"Relevance":newAttributeValidity[columnIndex]})
            AttributeDataJson = {"data": results}
                
    return json.dumps(AttributeDataJson)


#******************************************************************************
#Filter Data According to Selected Attributes
#******************************************************************************

@app.route('/dataset/sendAttributes', methods=['POST'])    
def filter_data():
    input_json = request.get_json(force=True)  
    Jsonkeys=input_json.keys()
    for data in session['columns']:
        if data in Jsonkeys:
            if input_json[data]:
                session['finalAttributes'].append(data)
                session['FinalAttributeCount'] += 1
                
    for data in session['Training_data']:
        temp=[]
        for columnData in session['finalAttributes']:
            temp.append(data[session['columns'].index(columnData)])
        session['Filtered_traning_data'].append(temp) 
     
    for data2 in session['Testing_data']:
        temp2=[]
        for columnData in session['finalAttributes']:
            temp2.append(data2[session['columns'].index(columnData)])
        session['Filtered_testing_data'].append(temp2)  
        
        
    return "Step 3 Done"

#******************************************************************************
#Train Decision Tree
#******************************************************************************

@app.route('/dataset/trainModel')    
def train_dicision_tree():
    classifierName = request.args.get('classifier')
    sampleRowData=[]
    for data in session['Filtered_traning_data'][len(session['Filtered_traning_data'])-1]:
        sampleRowData.append(data)
    sampleRowData.append(session['Training_Result'][len(session['Training_Result'])-1])
    if classifierName.lower() == "dicisiontree":
        trainerDT=DecisionTreeClassifier()
        trainerDT=trainerDT.fit(session['Filtered_traning_data'],session['Training_Result'])
        pickle.dump(trainerDT, open(os.path.splitext(session['Filename'])[0]+".sav", 'wb'))
        loaded_model_DT = pickle.load(open(os.path.splitext(session['Filename'])[0]+".sav", 'rb'))
        prediction_DT=loaded_model_DT.predict(session['Filtered_testing_data'])
        session['DT_accuracy']=0
        session['DT_accuracy'] += accuracy_score(session['Testing_Result'],prediction_DT)
        precisionDataDT=precision_recall_fscore_support(session['Testing_Result'], prediction_DT)[0].tolist()
        precisionDT=[]
        for data in precisionDataDT:
            precisionDT.append(data/(sum(precisionDataDT)))
        session['finalAttributes'].append("Result")
        training_result={"accuracy":session['DT_accuracy']*100,"totalNumberOfRows":session['rowNumber'],"numberOfRowsForTraining":len(session['Training_data']),"numberOfRowsForTesting":len(session['Testing_data']),"totalNumberOfAttributes":len(session['columns'])-1,"numberOfAttributesUsed":session['FinalAttributeCount'],"rowData":sampleRowData,"columnData":session['finalAttributes'],"classifier":"DecisionTree_Classifier","classification":session['UniqueList'],"Precision":precisionDT}
        return json.dumps(training_result)
    if classifierName.lower() == "knn":    
        trainerKNN=KNeighborsClassifier()
        trainerKNN=trainerKNN.fit(session['Filtered_traning_data'],session['Training_Result'])
        pickle.dump(trainerKNN, open(os.path.splitext(session['Filename'])[0]+".sav", 'wb'))
        loaded_model_KNN = pickle.load(open(os.path.splitext(session['Filename'])[0]+".sav", 'rb'))
        prediction_KNN=loaded_model_KNN.predict(session['Filtered_testing_data'])
        session['Training_Result']=0
        session['Training_Result']=accuracy_score(session['Testing_Result'],prediction_KNN)
        precisionDataKNN=precision_recall_fscore_support(session['Testing_Result'], prediction_KNN)[0].tolist()
        precisionKNN=[]
        for data in precisionDataKNN:
            precisionKNN.append(data/(sum(precisionDataKNN)))
        training_result={"accuracy":session['Training_Result']*100,"totalNumberOfRows":session['rowNumber'],"numberOfRowsForTraining":len(session['Training_data']),"numberOfRowsForTesting":len(session['Testing_data']),"totalNumberOfAttributes":len(session['columns'])-1,"numberOfAttributesUsed":session['FinalAttributeCount'],"rowData":sampleRowData,"columnData":session['finalAttributes'],"classifier":"KNN_Classifier","classification":session['UniqueList'],"Precision":precisionKNN}
        return json.dumps(training_result)


#******************************************************************************
#Rename Saved Model
#******************************************************************************


@app.route('/save')    
def rename_savedfile():
    aliceName = request.args.get('modelName')
    os.rename(os.path.splitext(session['Filename'])[0]+".sav", aliceName+'.sav')
    return "Done"
    
    
    


#******************************************************************************
#predicting
#******************************************************************************


@app.route('/dsw/predict', methods=['POST'])   
def predict_result():
    modelName = request.args.get('modelName')
    input_json_sample = request.get_json(force=True)  
    predictData=input_json_sample['rowData']
    classificationData=input_json_sample['Classification']
    precisionData=input_json_sample['Precision']
    saved_model = pickle.load(open(modelName+".sav", 'rb'))
    prediction=saved_model.predict(predictData)
    tempJsonPredict=[]
    count=0
    for data in classificationData:
       tempJsonPredict.append({"classification":str(data),"LikelyResult":precisionData[count]})
       count += 1  
    return json.dumps({"Result": str(prediction[0]),"Likely":tempJsonPredict})

###############################################################################
#Main
###############################################################################

if __name__ == '__main__':
    configuration = Configuration()
    # Configuring Proxies
    configuration.proxies()
    # Strating Server
    app.run('0.0.0.0',1612)
