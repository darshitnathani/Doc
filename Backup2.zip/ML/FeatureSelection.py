# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 11:47:27 2017

@author: dnathani
"""

# Feature Extraction with Univariate Statistical Tests (Chi-squared for classification)
import pandas
import numpy
from sklearn.feature_selection import RFE
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn import datasets
from sklearn import metrics
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
import random

acc1=[]
acc2=[]
acc3=[]
acc4=[]
acc5=[]

for index in range(0,100):
    
    dataset = datasets.load_iris()
    test = SelectKBest(score_func=chi2, k=4)
    fit = test.fit(dataset.data, dataset.target)
    # summarize scores
    numpy.set_printoptions(precision=4)
    print("**************Chi-squared************")
    print(fit.scores_)
    features = fit.transform(dataset.data)
    
    model = LogisticRegression()
    rfe = RFE(model, 1)
    fit = rfe.fit(dataset.data, dataset.target)
    print("*******************RFE****************")
    print("Num Features: %d") % fit.n_features_
    print("Selected Features: %s") % fit.support_
    print("Feature Ranking: %s") % fit.ranking_
    print("*******************feature_importances****************")
    model = ExtraTreesClassifier()
    model.fit(dataset.data, dataset.target)
    print(model.feature_importances_)
    print("*******************PCA****************")
    pca = PCA(n_components=4)
    fit = pca.fit(dataset.data)
    print("Explained Variance: %s") % fit.explained_variance_ratio_
         
         
    TrainData=list(dataset.data.tolist())
    TrainResult=list(dataset.target.tolist())
    
    
    newList = [[each_list[i] for i in [0,1,2,3]] for each_list in TrainData]
    full_data=zip(newList,TrainResult)
    random.shuffle(full_data)
    
    
    newList = [each_list[0]  for each_list in full_data]
    newList = [[each_list[i] for i in [0,2,3]] for each_list in newList]
    resultList = [each_list[1]  for each_list in full_data]
    train_data = newList[:75]
    test_data = newList[75:]
    train_result = resultList[:75]
    test_result = resultList[75:]
    trainerDT=DecisionTreeClassifier()
    trainerDT=trainerDT.fit(train_data,train_result)
    prediction_DT=trainerDT.predict(test_data)
    DT_accuracy = accuracy_score(test_result,prediction_DT)
    print("**************Chi-squared************")
    print(DT_accuracy)
    acc1.append(DT_accuracy)
    
    
    newList = [each_list[0]  for each_list in full_data]
    newList = [[each_list[i] for i in [1,2,3]] for each_list in newList]
    resultList = [each_list[1]  for each_list in full_data]
    train_data = newList[:75]
    test_data = newList[75:]
    train_result = resultList[:75]
    test_result = resultList[75:]
    trainerDT=DecisionTreeClassifier()
    trainerDT=trainerDT.fit(train_data,train_result)
    prediction_DT=trainerDT.predict(test_data)
    DT_accuracy = accuracy_score(test_result,prediction_DT)
    print("*******************RFE****************")
    print(DT_accuracy)
    acc2.append(DT_accuracy)
    
    
    newList = [each_list[0]  for each_list in full_data]
    newList = [[each_list[i] for i in [0,2,3]] for each_list in newList]
    resultList = [each_list[1]  for each_list in full_data]
    train_data = newList[:75]
    test_data = newList[75:]
    train_result = resultList[:75]
    test_result = resultList[75:]
    trainerDT=DecisionTreeClassifier()
    trainerDT=trainerDT.fit(train_data,train_result)
    prediction_DT=trainerDT.predict(test_data)
    DT_accuracy = accuracy_score(test_result,prediction_DT)
    print("*******************feature_importances****************")
    print(DT_accuracy)
    acc3.append(DT_accuracy)
    
    
    newList = [each_list[0]  for each_list in full_data]
    newList = [[each_list[i] for i in [1,2,3]] for each_list in newList]
    resultList = [each_list[1]  for each_list in full_data]
    train_data = newList[:75]
    test_data = newList[75:]
    train_result = resultList[:75]
    test_result = resultList[75:]
    trainerDT=DecisionTreeClassifier()
    trainerDT=trainerDT.fit(train_data,train_result)
    prediction_DT=trainerDT.predict(test_data)
    DT_accuracy = accuracy_score(test_result,prediction_DT)
    print("*******************PCA****************")
    print(DT_accuracy)
    acc4.append(DT_accuracy)
    
    newList = [each_list[0]  for each_list in full_data]
    newList = [[each_list[i] for i in [0,1,2]] for each_list in newList]
    resultList = [each_list[1]  for each_list in full_data]
    train_data = newList[:75]
    test_data = newList[75:]
    train_result = resultList[:75]
    test_result = resultList[75:]
    trainerDT=DecisionTreeClassifier()
    trainerDT=trainerDT.fit(train_data,train_result)
    prediction_DT=trainerDT.predict(test_data)
    DT_accuracy = accuracy_score(test_result,prediction_DT)
    print("*******************PCA Rev****************")
    print(DT_accuracy)
    acc5.append(DT_accuracy)


print(sum(acc1))
print(sum(acc2))
print(sum(acc3))
print(sum(acc4))
print(sum(acc5))

'''
3 4 1 2   96
4 2 3 1   
3 4 2 1
4 3 2 1
'''