# -*- coding: utf-8 -*-
"""
Created on Thu Jul 20 14:22:02 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul 20 12:33:31 2017

@author: dnathani
"""



print(__doc__)

import numpy as np
from sklearn.svm import SVR
import matplotlib.pyplot as plt

time   = np.linspace(0,10,11)
	
signal=time*time+10*np.sin(10*time)


new_time=[]
for data in time:
    new_time.append([data])

svr_poly = SVR(kernel='poly', C=1e3, degree=3)
y_poly = svr_poly.fit(new_time, signal).predict(new_time)

plt.plot(new_time, signal, color='darkorange',lw=4)
plt.plot(new_time, y_poly, color='cornflowerblue', lw=3)
plt.xlim(0,10)
plt.xlabel('Time')
plt.ylabel('Signal')
plt.title('Regression Order 3')
plt.legend()
plt.show()
print(y_poly)