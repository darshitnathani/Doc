# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 11:58:02 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 14:39:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 14:49:47 2017

@author: dnathani
"""

import flask
from flask import request
import os
from flask import Flask
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_recall_fscore_support
import pandas as pd
import pickle
import json
import csv
import random


###############################################################################
#Configuration
###############################################################################


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"

###############################################################################
#Flask Configuration
###############################################################################
        
        
app = Flask(__name__, static_url_path="", static_folder="static")


###############################################################################
#Global Variables
###############################################################################
columns=[]
rowsData=[]
FileData=[]
FileResult=[]
attributeValidity=[]
rowNumber=0
FileName=""
Training_data=[]
Testing_data=[]
Training_Result=[]
Testing_Result=[]
Filtered_traning_data=[]
finalAttributes=[]
FinalAttributeCount=0
Filtered_testing_data=[]
KNNSelected=False
DTSelected=False
DT_accuracy=0
KNN_accuracy=0
data_Faltu1=[]
data_Faltu2=[]
AttributeDataJson={}
uniqueData=set()
###############################################################################
#Training
###############################################################################
def reset_Data():
    global columns
    global rowsData
    global FileData
    global FileResult
    global attributeValidity
    global rowNumber
    global FileName
    global Training_data
    global Testing_data
    global Training_Result
    global Testing_Result
    global Filtered_traning_data
    global finalAttributes
    global FinalAttributeCount
    global Filtered_testing_data
    global KNNSelected
    global DTSelected
    global DT_accuracy
    global KNN_accuracy
    global data_Faltu1
    global data_Faltu2
    global AttributeDataJson
    global uniqueData
    
    columns=[]
    rowsData=[]
    FileData=[]
    FileResult=[]
    attributeValidity=[]
    rowNumber=0
    FileName=""
    Training_data=[]
    Testing_data=[]
    Training_Result=[]
    Testing_Result=[]
    Filtered_traning_data=[]
    finalAttributes=[]
    FinalAttributeCount=0
    Filtered_testing_data=[]
    KNNSelected=False
    DTSelected=False
    DT_accuracy=0
    KNN_accuracy=0
    data_Faltu1=[]
    data_Faltu2=[]
    AttributeDataJson={}
    uniqueData=set()

#******************************************************************************
#Attribute Selection (First Call)
#******************************************************************************

@app.route('/dataset/split')
def attribute_selection():
    filename = request.args.get('file')
    Training = int(request.args.get('Training'))
    Testing = int(request.args.get('Testing'))
    Hold = int(request.args.get('Hold'))
    reset_Data()
    global FileName
    FileName = filename+".csv"
    # TODO:ADD FilePath
    filepath="TODO"
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",FileName)
    with open(filepath,"r") as f:
            global columns
            reader = csv.reader(f,delimiter = ",")
            columns=reader.next()
            global rowsData
            global FileData
            global FileResult
            global rowNumber
            for row in reader:
                rowsData.append(row)
                rowNumber += 1
            for newLine in rowsData:
                temp2=[]
                for dataindex in range(0,(len(columns)-1)):
                    
                    temp2.append(float(newLine[dataindex]))
                FileResult.append(int(newLine[len(columns)-1]))
                FileData.append(temp2)
    model = LogisticRegression()
    rfe = RFE(model, int(len(columns)*0.4))
    rfe = rfe.fit(FileData, FileResult)
    global attributeValidity
    attributeValidity=rfe.support_
    return split_Data(Training,Testing,Hold)
    #return "STEP 1 Done"

#******************************************************************************
#Split Data (Second Call)
#******************************************************************************
#
#@app.route('/splitData', methods=['POST'])    
#def Split():
#    input_json = request.get_json(force=True)  
#    Training=input_json["Training"]
#    Testing=input_json["Testing"]
#    Hold=input_json["Hold"]
#    return split_Data(Training,Testing,Hold)

def split_Data(Training,Testing,Hold):
    # TODO:ADD FilePath
    #filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","creditcard.csv")
    print(Training,Testing,Hold)
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",FileName)
    with open(filepath,"r") as f:
            reader = csv.reader(f,delimiter = ",")
            columns=reader.next()
            
            data = list(reader)
            row_count = len(data)
            trainEnd=int(((row_count*Training)+1)/100)
            print(trainEnd)
            testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
            print(testEnd)
            #randomList=np.random.randint(1,row_count,size=row_count)
            randomList=random.sample(range(0,row_count), row_count)
            trainingData=[]
            testingData=[]

            for data in range(0,trainEnd):
                trainingData.append(randomList[data])
            for data in range(trainEnd,testEnd):
                testingData.append(randomList[data])

    with open(filepath,"r") as f:
            rowsData=[]
            reader = csv.reader(f,delimiter = ",")
            for row in reader:
                rowsData.append(row)
    
            global Training_data
            global Testing_data
            global Training_Result
            global Testing_Result           
           
            for data in trainingData:
                Training_data.append(FileData[data])
                Training_Result.append(FileResult[data])
                
            
            for data in testingData:
                Testing_data.append(FileData[data])
                Testing_Result.append(FileResult[data])
          
            
            df = pd.read_csv(filepath)
            
            columnResults=[]
            for data in columns:
                columnResults.append(df[data].values)
            
            new_col_result=[]
            for data in columnResults:
                temp=[]
                for data_inside in data:
                    temp.append(float(data_inside))
                new_col_result.append(temp)
            newAttributeValidity=attributeValidity.tolist()
            groupingData=range(0,len(columns)-1)
            groupingData.append(0)
            global uniqueData
            for data in new_col_result[len(columns)-1]:
                uniqueData.add(data)
            UniqueList=list(uniqueData)
            
            group=[]
            for data in range(0,len(columns)-1):
                group.append(zip(new_col_result[groupingData[data]],new_col_result[groupingData[data+1]]))
            colorData=[]
            for data in range(0,len(columns)):
                tempColor=[]
                tempColor.append(int(random.random()*255))
                tempColor.append(int(random.random()*255))
                tempColor.append(int(random.random()*255))
                colorData.append(tempColor)    
                
            results=[]
            for columnIndex in range(0,len(columns)-1):
                tempJsonData=[]
                colorCount=0
                for classificationData in UniqueList:
                    mesData=[]
                    for data in range(0,len(new_col_result[len(columns)-1])):
                        if new_col_result[len(columns)-1][data] == classificationData:
                            mesData.append(group[columnIndex][data])
                    tempColorData="rgba({}, {}, {}, .5)".format(colorData[colorCount][0],colorData[colorCount][1],colorData[colorCount][2])        
                    tempJsonData.append({"name":classificationData,"data":mesData,"color":tempColorData})
                    colorCount += 1
                tempRelevance = ""
                if newAttributeValidity[columnIndex]:
                    tempRelevance="Relevent"
                else:
                    tempRelevance="Irrelevent"
                results.append({"attributeName":columns[columnIndex],"attributeData":tempJsonData, "RelevanceValue": tempRelevance,"Relevance":newAttributeValidity[columnIndex]})
                
                
#            newAttributeValidity.append(True)
#            count=0
#            results=[]
#            for data in new_col_result:
#                results.append({columns[count]:data,"Validity":newAttributeValidity[count]})
#                count += 1
#           
            global AttributeDataJson
            
            AttributeDataJson = {"data": results}
    return "Success"


@app.route('/dataset/getAttributes')
def getAttribute():
    global AttributeDataJson
    return json.dumps(AttributeDataJson)
#******************************************************************************
#Filter Data According to Selected Attributes
#******************************************************************************

@app.route('/dataset/sendAttributes', methods=['POST'])    
def filter_data():
    input_json = request.get_json(force=True)  
    Jsonkeys=input_json.keys()
    global finalAttributes
    global FinalAttributeCount
    for data in columns:
        if data in Jsonkeys:
            if input_json[data]:
                finalAttributes.append(data)
                FinalAttributeCount += 1
    
    global Filtered_traning_data
    global Filtered_testing_data
    
    for data in Training_data:
        temp=[]
        for columnData in finalAttributes:
            temp.append(data[columns.index(columnData)])
        Filtered_traning_data.append(temp) 
     
    for data2 in Testing_data:
        temp2=[]
        for columnData in finalAttributes:
            temp2.append(data2[columns.index(columnData)])
        Filtered_testing_data.append(temp2)  
        
        
    return "Step 3 Done"

#******************************************************************************
#Train Decision Tree
#******************************************************************************

@app.route('/dataset/trainModel')    
def train_dicision_tree():
    classifierName = request.args.get('classifier')
    if classifierName.lower() == "decisiontree_classifier":
        global DTSelected
        DTSelected=True
        trainerDT=DecisionTreeClassifier()
        global Filtered_traning_data
        trainerDT=trainerDT.fit(Filtered_traning_data,Training_Result)
        #pickle.dump(trainerDT, open(os.path.splitext(FileName)[0]+"_DT.sav", 'wb'))
        #loaded_model_DT = pickle.load(open(os.path.splitext(FileName)[0]+"_DT.sav", 'rb'))
        pickle.dump(trainerDT, open(os.path.splitext(FileName)[0]+".sav", 'wb'))
        loaded_model_DT = pickle.load(open(os.path.splitext(FileName)[0]+".sav", 'rb'))
        prediction_DT=loaded_model_DT.predict(Filtered_testing_data)
        global DT_accuracy
        global uniqueData
        DT_accuracy=0
        DT_accuracy += accuracy_score(Testing_Result,prediction_DT)
        precisionDataDT=precision_recall_fscore_support(Testing_Result, prediction_DT)[0].tolist()
        precisionDT=[]
        print(precisionDataDT)
        for data in precisionDataDT:
            precisionDT.append(data/(sum(precisionDataDT)))
        sampleRowData=[]
        for data in Filtered_traning_data[len(Filtered_traning_data)-1]:
            sampleRowData.append(data)
        sampleRowData.append(Training_Result[len(Training_Result)-1])
        finalAttributesList=[]
        finalAttributes.append("Result")
        finalAttributesList=list(set(finalAttributes))
        training_result={"accuracy":DT_accuracy*100,"totalNumberOfRows":rowNumber,"numberOfRowsForTraining":len(Training_data),"numberOfRowsForTesting":len(Testing_data),"totalNumberOfAttributes":len(columns)-1,"numberOfAttributesUsed":FinalAttributeCount,"rowData":sampleRowData,"columnData":finalAttributesList,"classifier":"Decision_Tree","classification":list(uniqueData),"Precision":precisionDataDT}
        return json.dumps(training_result)
    if classifierName.lower() == "knn_classifier":
        global KNNSelected
        KNNSelected=True    
        trainerKNN=KNeighborsClassifier()
        global Filtered_traning_data
        trainerKNN=trainerKNN.fit(Filtered_traning_data,Training_Result)
        #pickle.dump(trainerKNN, open(os.path.splitext(FileName)[0]+"_KNN.sav", 'wb'))
        #loaded_model_KNN = pickle.load(open(os.path.splitext(FileName)[0]+"_KNN.sav", 'rb'))
        pickle.dump(trainerKNN, open(os.path.splitext(FileName)[0]+".sav", 'wb'))
        loaded_model_KNN = pickle.load(open(os.path.splitext(FileName)[0]+".sav", 'rb'))
        prediction_KNN=loaded_model_KNN.predict(Filtered_testing_data)
        global KNN_accuracy
        global uniqueData
        KNN_accuracy=0
        KNN_accuracy=accuracy_score(Testing_Result,prediction_KNN)
        precisionDataKNN=precision_recall_fscore_support(Testing_Result, prediction_KNN)[0].tolist()
        precisionKNN=[]
        for data in precisionDataKNN:
            precisionKNN.append(data/(sum(precisionDataKNN)))
        sampleRowData=[]
        for data in Filtered_traning_data[len(Filtered_traning_data)-1]:
            sampleRowData.append(data)
        sampleRowData.append(Training_Result[len(Training_Result)-1])
        finalAttributesList=[]
        finalAttributes.append("Result")
        finalAttributesList=list(set(finalAttributes))
        training_result={"accuracy":KNN_accuracy*100,"totalNumberOfRows":rowNumber,"numberOfRowsForTraining":len(Training_data),"numberOfRowsForTesting":len(Testing_data),"totalNumberOfAttributes":len(columns)-1,"numberOfAttributesUsed":FinalAttributeCount,"rowData":sampleRowData,"columnData":finalAttributesList,"classifier":"KNN_Classifier","classification":list(uniqueData),"Precision":precisionDataKNN}
        return json.dumps(training_result)

#******************************************************************************
#Train KNN
#******************************************************************************
#
#@app.route('/trainKNN')    
#def train_KNN():
#    global KNNSelected
#    KNNSelected=True    
#    trainer=KNeighborsClassifier()
#    global Filtered_traning_data
#    Filtered_traning_data=[[5.2, 3.4, 1.4, 0.2]]
#    trainer=trainer.fit(Filtered_traning_data,Training_Result)
#    pickle.dump(trainer, open(os.path.splitext(FileName)[0]+"_KNN.sav", 'wb'))
#    loaded_model = pickle.load(open(os.path.splitext(FileName)[0]+"_KNN.sav", 'rb'))
#    prediction=loaded_model.predict(Filtered_testing_data)
#    global KNN_accuracy
#    KNN_accuracy=accuracy_score(Testing_Result,prediction) 
#    print(KNN_accuracy)
#    training_result={"Accuracy":KNN_accuracy*100,"NumberOfRows":rowNumber,"NumberOfTrainingRows":len(Training_data),"NumberOfTestingRows":len(Testing_data),"NumberOfAttributes":len(columns)-1,"NoOfSelectedAttributes":FinalAttributeCount}
#    return json.dumps(training_result)


#******************************************************************************
#Rename Saved Model
#******************************************************************************


@app.route('/save')    
def rename_savedfile():
    aliceName = request.args.get('modelName')
    os.rename(os.path.splitext(FileName)[0]+".sav", aliceName+'.sav')
#    if KNNSelected:
#        os.rename(os.path.splitext(FileName)[0]+"_KNN.sav", aliceName+'.sav')
#    if DTSelected:
#        os.rename(os.path.splitext(FileName)[0]+"_DT.sav", aliceName+'.sav')
    return "Done"
    
    
    


#******************************************************************************
#predicting
#******************************************************************************


@app.route('/dsw/predict', methods=['POST'])   
def predict_result():
    modelName = request.args.get('modelName')
    input_json_sample = request.get_json(force=True)  
    predictData=input_json_sample['rowData']
    classificationData=input_json_sample['Classification']
    precisionData=input_json_sample['Precision']
    saved_model = pickle.load(open(modelName+".sav", 'rb'))
    prediction=saved_model.predict(predictData)
    tempJsonPredict=[]
    count=0
    for data in classificationData:
       tempJsonPredict.append({"classification":str(data),"LikelyResult":precisionData[count]*100})
       count += 1
        
    return json.dumps({"Result": str(prediction[0]),"Likely":tempJsonPredict})

###############################################################################
#Main
###############################################################################

if __name__ == '__main__':
    configuration = Configuration()
    # Configuring Proxies
    configuration.proxies()
    # Strating Server
    app.run('0.0.0.0',1612)

'''
    
filename = 'CreditCardModleDT.sav'
    
# load the model from disk
loaded_model = pickle.load(open(filename, 'rb'))
prediction2=loaded_model.predict(TestTData)
accNew=accuracy_score(TestRData,prediction2)
data=loaded_model.predict([172583,-0.396918844,0.487681002,1.749180161,-0.448275539,0.073370105,-0.154573775,0.441296263,-0.053160026,0.350395219,-0.337734941,0.838187658,0.431894088,-0.695062593,-0.007505928,-0.032102349,0.007546238,-0.672374037,0.447118913,0.538019995,-0.06238808,-0.073548184,-0.043524345,-0.003460215,-0.035273194,-0.710456038,-0.638312219,-0.107173342,-0.048507421,5])
print(data)
print(accNew)

'''
###############################################################################
#Global Variables
###############################################################################
#columns=[]
#rowsData=[]
#FileData=[]
#FileResult=[]
#attributeValidity=[]
#rowNumber=0
#FileName=""
#Training_data=[]
#Testing_data=[]
#Training_Result=[]
#Testing_Result=[]
################################################################################
#Training
###############################################################################


#******************************************************************************
#Attribute Selection (First Call)
#******************************************************************************
'''
@app.route('/accTest/<filename>')
def attribute_selection(filename):
    global FileName
    FileName = filename+".csv"
    # TODO:ADD FilePath
    filepath="TODO"
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",FileName)
    with open(filepath,"r") as f:
            global columns
            reader = csv.reader(f,delimiter = ",")
            columns=reader.next()
            print(columns)
            global rowsData
            global FileData
            global FileResult
            global rowNumber
            for row in reader:
                rowsData.append(row)
                rowNumber += 1
            for newLine in rowsData:
                temp2=[]
                for dataindex in range(0,(len(columns)-1)):
                    temp2.append(float(newLine[dataindex]))
                    FileResult.append(int(newLine[len(columns)-1]))
                    FileData.append(temp2)
                
    model = LogisticRegression()
    # create the RFE model and select 3 attributes
    rfe = RFE(model, int(columns*0.4))
    rfe = rfe.fit(FileResult, FileData)
    # summarize the selection of the attributes
    global attributeValidity
    attributeValidity=rfe.support_
    print(rfe.ranking_)
    return "STEP 1 Done"

#******************************************************************************
#Split Data (Second Call)
#******************************************************************************

@app.route('/splitData', methods=['POST'])    
def Split():
    input_json = request.get_json(force=True)  
    print(input_json)
    Training=input_json["Training"]
    Testing=input_json["Testing"]
    Hold=input_json["Hold"]
    print(Training,Testing,Hold)
    split_Data(Training,Testing,Hold)
    return "Data Splited Succesfully"

def split_Data(Training,Testing,Hold):
    # TODO:ADD FilePath
    #filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","creditcard.csv")
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",FileName)
    with open(filepath,"r") as f:
            reader = csv.reader(f,delimiter = ",")
            columns=reader.next()
            print(columns)
            data = list(reader)
            row_count = len(data)
            trainEnd=int(((row_count*Training)+1)/100)
            testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
            randomList=np.random.randint(1,row_count,size=row_count)
            trainingData=[]
            testingData=[]
            for data in range(0,trainEnd):
                trainingData.append(randomList[data])
            for data in range(trainEnd,testEnd):
                testingData.append(randomList[data])
                
            print(len(trainingData),len(testingData))
      
    with open(filepath,"r") as f:
            rowsData=[]
            reader = csv.reader(f,delimiter = ",")
            for row in reader:
                rowsData.append(row)
    
            global Training_data
            global Testing_data
            global Training_Result
            global Testing_Result           
            
            for data in trainingData:
                Training_data.append(FileData[data])
                Training_Result.append(FileResult[data])
                
            
            for data in testingData:
                Testing_data.append(FileData[data])
                Testing_Result.append(FileResult[data])
                    
    
    return "Done"
'''
#
#trainer = pickle.load(open("../CreditCardModleDT.sav", 'rb'))
#trainer2 = pickle.load(open("../CreditCardModleKNN.sav", 'rb'))
#    
#Training=50
#Testing=50
#Hold=0
#
#@app.route('/splitData', methods=['POST'])    
#def Split():
#    input_json = request.get_json(force=True)  
#    print(input_json)
#    Training=input_json["Training"]
#    Testing=input_json["Testing"]
#    Hold=input_json["Hold"]
#    
#    print(Training,Testing,Hold)
#    split_Data(Training,Testing,Hold)
#    
#    return "Data Splited Succesfully"
#
#def split_Data(Training,Testing,Hold):
#    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","creditcard.csv")
#    
#    with open(filepath,"r") as f:
#            reader = csv.reader(f,delimiter = ",")
#            columns=reader.next()
#            print(columns)
#            data = list(reader)
#            row_count = len(data)
#            trainEnd=int(((row_count*Training)+1)/100)
#            testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
#            randomList=np.random.randint(1,row_count,size=row_count)
#            trainingData=[]
#            testingData=[]
#            for data in range(0,trainEnd):
#                trainingData.append(randomList[data])
#            for data in range(trainEnd,testEnd):
#                testingData.append(randomList[data])
#                
#            print(len(trainingData),len(testingData))
#      
#    with open(filepath,"r") as f:
#            rowsData=[]
#            reader = csv.reader(f,delimiter = ",")
#            for row in reader:
#                rowsData.append(row)
#               
#            Training_data=[]
#            Testing_data=[]
#            
#            for data in trainingData:
#                Training_data.append(rowsData[data])
#                
#            
#            for data in testingData:
#                Testing_data.append(rowsData[data])
#            
#            TrainingDataResult=[]
#            TrainingInputData=[]
#            for newLine in Training_data:
#                    temp2=[]
#                    for dataindex in range(0,(len(columns)-1)):
#                        temp2.append(float(newLine[dataindex]))
#                    TrainingDataResult.append(int(newLine[len(columns)-1]))
#                    TrainingInputData.append(temp2)
#                    
#                    
#            TestingDataResult=[]
#            TestingInputData=[]
#            for newLine in Testing_data:
#                    temp2=[]
#                    for dataindex in range(0,(len(columns)-1)):
#                        temp2.append(float(newLine[dataindex]))
#                    TestingDataResult.append(int(newLine[len(columns)-1]))
#                    TestingInputData.append(temp2)
#                    
#    
#    return "Done"
#    
#@app.route('/accTest/<filename>')    
#def trained_test(filename):
#    
#    testData=dataSetTest(filename)
#    TestTData=[]
#    TestRData=[]
#    
#    for data in testData:
#        TestTData.append(data[0])
#        TestRData.append(data[1])
#        
#    prediction=trainer.predict(TestTData)
#    acc1=accuracy_score(TestRData,prediction)
#    
#    prediction2=trainer2.predict(TestTData)
#    acc2=accuracy_score(TestRData,prediction2)
#    
#    
#    print(acc1*100)
#    print(acc2*100)
#    result={"Modle1Acc": acc1*100, "Modle2Acc": acc2*100}
#    return json.dumps(result)
#    
#
#@app.route('/predict')    
#def prredict_result():
#    
#    testData=dataSetTest()
#    TestTData=[]
#    TestRData=[]
#    
#    for data in testData:
#        TestTData.append(data[0])
#        TestRData.append(data[1])
#        
#    prediction=""
#    print(prediction)
#    
#    prediction2=trainer2.predict(TestTData)
#    acc2=accuracy_score(TestRData,prediction2)
#    
#    return "TODO"
#
#
#
#
#
#@app.route('/')
#def hello_world():
#    #return flask.render_template('index.html')
#    return "ML.html"
#
#@app.route('/machineLearning')
#def machine_learning():
#    return flask.render_template('ML.html')