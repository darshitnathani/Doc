# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 13:00:41 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 19:59:46 2017

@author: dnathani
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
import seaborn as sns
from Tkinter import StringVar
from Tkinter import Tk
from Tkinter import Label
from Tkinter import OptionMenu
from Tkinter import Button
import tkMessageBox
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
import pandas

def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("creditcard - Copy - Copy (2).csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,19):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[19].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    #print(Result)    
    return Result

def dataSetTest():

    inputData=[]
    dataResult=[]
    fobj=open("creditcardTest - Copy (2).csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,19):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[19].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    #print(Result)
    return Result

creditCard=dataSetNo1()
testData=dataSetTest()

TData=[]
RData=[]

for data in creditCard:
    TData.append(data[0])
    RData.append(data[1])
    
    
TestTData=[]
TestRData=[]

for data in testData:
    TestTData.append(data[0])
    TestRData.append(data[1])

#print(TestRData)

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]

for data in TData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])
    
trainer=DecisionTreeClassifier()

trainer=trainer.fit(TData,RData)
prediction=trainer.predict(TestTData)
acc1=accuracy_score(TestRData,prediction)


trainer2=KNeighborsClassifier()

trainer2=trainer2.fit(TData,RData)
prediction2=trainer2.predict(TestTData)
acc2=accuracy_score(TestRData,prediction2)

#print(prediction2)

print(acc1)
print(acc2)

result=[]
result.append(acc1)
result.append(acc2)
width = 1/1.5
plt.figure(num=7)
plt.bar(range(len(result)), result, width, color="blue")
#print(trainer.predict([4462,-2.303349568,1.75924746,-0.359744743,2.330243051,-0.821628328,-0.075787571,0.562319782,-0.399146578,-0.238253368,-1.525411627,2.032912158,-6.560124295,0.022937323,-1.470101536,-0.698826069,-2.282193829,-4.781830856,-2.615664945,-1.334441067,-0.430021867,-0.294166318,-0.932391057,0.172726296,-0.087329538,-0.156114265,-0.542627889,0.039565989,-0.153028797,239.93]))
#print(trainer.predict([172566,-1.500110264,1.129084563,1.227705363,0.820677038,1.058160283,-0.330762069,-0.35108621,-0.001351465,1.297495619,0.597512215,-0.071612089,-0.531929672,0.097345672,-0.08446113,1.726581495,20.25]))
plt.figure(num=1)
plt.scatter(trainingDataX, trainingDataY,c=RData)
plt.figure(num=2)
plt.scatter(trainingDataP, trainingDataQ,c=RData)
plt.figure(num=3)
plt.scatter(trainingDataY, trainingDataP,c=RData)
plt.figure(num=4)
plt.scatter(trainingDataX, trainingDataQ,c=RData)
plt.figure(num=5)
plt.scatter(trainingDataX, trainingDataP,c=RData)
plt.figure(num=6)
plt.scatter(trainingDataY, trainingDataQ,c=RData)
