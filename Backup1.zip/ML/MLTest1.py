# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 19:49:28 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 14:45:43 2017

@author: rbarry
"""

import configparser
import logging
import csv
import re
import os
from io import StringIO
from collections import defaultdict
import subprocess
import shutil
import zipfile
import smtplib
from email.mime.text import MIMEText


###############################################################################
# Global
###############################################################################
DEFAULT_LOG_LEVEL = "INFO"  # Overwritten by config.
DEFAULT_LOG_NAME = 'CDI_log'
DEFAULT_CONFIG_FILENAME = "TestConfig.ini"


###############################################################################
# General
###############################################################################
class CdiObject:
    def __init__(self, *args, **kwargs):
        self.logger = logging.getLogger(DEFAULT_LOG_NAME)


###############################################################################
# Error Handling and Logging
###############################################################################
class CdiErrorInterface(CdiObject, Exception):
    def __init__(self, error_msg):
        super().__init__(error_msg)
        self.log_error_msg(error_msg)

    def log_error_msg(self, error_msg):
        raise NotImplementedError


class Error0(CdiErrorInterface):
    def log_error_msg(self, error_msg):
        self.logger.fatal(error_msg)


class Error1(CdiErrorInterface):
    def log_error_msg(self, error_msg):
        self.logger.error(error_msg)


class Error2(CdiErrorInterface):
    def log_error_msg(self, error_msg):
        self.logger.error(error_msg)


class CaptureLogging:
    def __init__(self, current_session, log_level=DEFAULT_LOG_LEVEL):
        self.logger = logging.getLogger(DEFAULT_LOG_NAME)
        self.update_log_level(log_level)
        self.current_session = current_session

    @staticmethod
    def get_formatter():
        return logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
            )

    @staticmethod
    def make_handler(stream=None):
        ch = logging.StreamHandler(stream)
        ch.setFormatter(CaptureLogging.get_formatter())
        return ch

    def add_file_handler(self, log_file_path_name):
        log_file_handler = logging.FileHandler(
                                log_file_path_name,
                                mode='a',
                            )
        log_file_handler.setFormatter(CaptureLogging.get_formatter())
        self.handlers.append(log_file_handler)
        self.logger.addHandler(log_file_handler)

    def add_stream_handlers(self):
        self.handlers = []
        # TODO: Add a file append stream
        for stream in [self.current_session, None]:
            self.handlers.append(self.make_handler(stream))
        for handler in self.handlers:
            self.logger.addHandler(handler)

    def initialize_file_logging(self, log_file_pathname):
        try:
            self.add_file_handler(log_file_pathname)
        except KeyError as err:
            raise Error0('Cannot open LogFile: {}'.format(
                    log_file_pathname))

    def update_log_level(self, log_level):
        if isinstance(log_level, str):
            log_level = getattr(logging, log_level)
        self.logger.setLevel(log_level)

    def __enter__(self):
        self.logger.propagate = 0
        self.add_stream_handlers()
        return self

    def __exit__(self, *args, **kwargs):
        for handler in self.handlers:
            self.logger.removeHandler(handler)


###############################################################################
# CONFIG
###############################################################################
class ConfigReaderValidator(CdiObject):
    def read_config(self, cfg_filename):
        basic_cfg = configparser.ConfigParser()
        basic_cfg.read(cfg_filename)
        try:
            self.validate_basic_config(basic_cfg)
            product_cfg_fname = basic_cfg['General']['ProductConfigPath']
            product_cfg = self.read_product_cfg(product_cfg_fname)
            self.validate_unique_path(product_cfg)
            #self.validate_CSV_data(product_cfg)
            #self.validate_product_config(basic_cfg, product_cfg)

        except Exception as err:
            raise Error0('Aborting: {}'.format(err))
        return Config(basic_cfg, product_cfg)

    def add_number(self, x, y):
        return x+y

    def validate_CSV_data(self, product_cfg):
        unique_combination = []
        for values in product_cfg.values():
            for value in values.values():
                unique_combo = "".join([value['product'],"-",value['study'],"-",value['vendor'],"-",value['filename']])
                if unique_combo in unique_combination:
                    raise Exception("Unique Combination Rule Violation. We have duplicate entries for product = {}, study = {}, vendor = {}, filename = {}".format(value['product'],value['study'],value['vendor'],value['filename']))
                else:
                    unique_combination.append(unique_combo)
        return True
                    
    
    def validate_unique_path(self,product_cfg):
        list_combination_of_prod_study_vendor = []
        list_path_name = []
        list_sas_path_name = []
        for values in product_cfg.values():
            temp = list(values.values())
            path = temp[0]['path']
            sas_path = temp[0]['sas program path']
            for value in values.values():
                if path != value['path']:
                    raise Exception("For product '{}', Study '{}' and Vendor '{}', we have more than one intermediate paths".format(value['product'],value['study'],value['vendor']))
                elif sas_path != value['sas program path']:
                    raise Exception("For product '{}', Study '{}' and Vendor '{}', we have more than one SAS program paths".format(value['product'],value['study'],value['vendor']))
        return True
	
    def is_general_section_valid(self, basic_cfg):
        def check_path_exists(section, config_item):
            pathname = section[config_item]
            if not os.path.exists(pathname):
                msg = "(General) {0}: '{1}'".format(config_item, pathname)
                self.logger.error(msg)
                raise FileNotFoundError(msg)
        check_path_exists(basic_cfg['General'], 'ProductConfigPath')
        check_path_exists(basic_cfg['General'], 'LogFilePath')
        # TODO: Check the above if is necessary
        check_path_exists(basic_cfg['Check'], 'CheckLogFileBasePath')
        return True

    def is_email_section_valid(self, basic_cfg):
        '''
        NOTE: This regex isn't perfect but it should match all of the cases
        relevant to Amgen.
        '''
        email_regex = r"^([a-zA-Z0-9-.]+)@" + \
            "([a-zA-Z0-9-.]+)\.([a-zA-Z]{2,3}|[0-9]{1,3})(]?)$"

        def check_email_address(email_address):
            if re.match(email_regex, email_address) is not None:
                return
            raise Error0('Invalid Email Address: {}'.format(email_address))

        def validate_emails(email_list):
            for email in email_list.split(","):
                check_email_address(email.strip())

        for email_type in basic_cfg['Email']:
            validate_emails(basic_cfg['Email'][email_type])

        return True

    def validate_basic_config(self, basic_cfg):
        self.is_general_section_valid(basic_cfg)
        #self.is_labname_section__valid(basic_cfg)
        basic_cfg['Labtest']
        #basic_cfg['Product']
        self.is_email_section_valid(basic_cfg)

    def validate_unique(self, product_cfg):
        for data in product_cfg:
            print( "data received for validate unique :", data)

    def read_product_cfg(self, product_cfg_filename):
        product_cfg = defaultdict(dict)
        product_cfg2 = defaultdict(dict)        
        with open(product_cfg_filename) as fp:
            csvdata = csv.DictReader(fp, delimiter=",", quotechar='"')
            for row in csvdata:
                product_cfg[row['product'], row['study'], row['vendor']][row['filename']] = row
        return product_cfg


class Config(CdiObject):
    def __init__(self, basic, product):
        super().__init__()
        self.basic = basic
        self.product = product

    def get_path_list(self):
        directory_list = set()  # For unique directories
        labname_section = self.basic['General']['IncomingDirectories']
        #for labname in labname_section:
        directory_list = directory_list.union(
                set(labname_section.split(';'))
            )
        return directory_list


###############################################################################
# UTILITY
###############################################################################
class FileUtil(CaptureLogging):
    def move_file(self, src, dst):
        try:
            if (os.path.isfile(src)):
                shutil.copy(src, dst)
                msg = "File '{}' moved to '{}'."\
                      .format(
                          src,
                          dst
                       )
                self.logger.debug(msg)
        except Exception as err:
            raise Error2("Could not move file '{}' to location '{}'".format(src, dst))

    def dir_name_generator(self):
        if self.invsite:
            name = self.rcvdate + self.invsite
        else:
            name = self.rcvdate + self.results
        return name

    def create_dir(self, directory):
        try:
            if not os.path.exists(directory):
                os.makedirs(directory)
                self.logger.info("'{}' directory created.".format(directory))
        except OSError as err:
            raise OSError("Error while creating directory: {}".format(err))


###############################################################################
# SCAN
###############################################################################
class Scanner(CdiObject):
    def __init__(self, directory_list):
        super().__init__()
        self.directory_list = directory_list
        

    def get_next_scan_path(self):
        for directory in self.directory_list:
            yield directory

    def get_next_file_entry(self):
        try:
            for path in self.get_next_scan_path():
                self.logger.info("Scanning path: {}".format(path))
                for entry in os.scandir(path):
                    if entry.is_file():
                        yield entry
                self.logger.info("Finished scanning path: {}".format(path))
        except Exception as err:
            raise Error0("Aborting Scanning, {}".format(err))


###############################################################################
# ENTRY PIPELINE
###############################################################################
class PipelineStepInterface(CdiObject):
    def __init__(self, entry=None, past_results={}):
        super().__init__()
        self.entry = entry
        self.past_results = past_results

    def process(self, *args, **kwargs):
        raise NotImplementedError


class Pipeline(CdiObject):
    def __init__(self, config):
        super().__init__()
        self.config = config

    def execute_pipeline(self, steps):
        for entry in Scanner(config.get_path_list()).get_next_file_entry():
            self.logger.info("Begin Processing file. Path: {}".format(
                    entry.path))
            result = {}
            for StepClass in steps:
                try:
                    result = StepClass(entry, result).process(self.config)
                    msg = "{} step completed successfully with results {}"\
                        .format(
                            StepClass.__name__,
                            result,
                        )
                    self.logger.debug(msg)
                except (Error1, Error2) as err:
                    msg = "Error processing entry. Skipping to next entry."
                    self.logger.info(msg)
                    break
            else:  # Only executes if no break
                self.logger.info("Processing complete for entry: {}".format(
                    entry.name))


###############################################################################
# STEP: PARSE
###############################################################################
class Parser(PipelineStepInterface):
    regex = None
    def get_regex(self, labtests):
        # TODO: Is this all the date formats?
        regex_str = """
^(?P<product>(ne|ca|epo|g)    # Product is either from this list
|[a-zA-Z0-9]+)_?              # or is the first word prior to a '_'
(?P<study>[a-zA-Z0-9]+)       # Study is the following set of digits
(_(?P<vendor>[a-zA-Z0-9]+))  # bname is next word between _
(?P<labtest>(_({}))*)         # labtests might be here (can match '')
_(?P<rcvdate>[0-9]+[a-zA-Z]*[0-9]+)    # Rcvdate is here
(_(?P<invsite>invsite))?      # Invsite may be here
(_(?P<results>results))?      # Results may be here
(?P<additional>.*?)           # Additional stuff may be on line (can match '')
(\.[a-zA-Z0-9]+)*(?P<extension>(.zip|.ZIP))$    # Last extension"""\
        .format(
            '|'.join(labtests)
        )
        return re.compile(regex_str, re.VERBOSE | re.IGNORECASE)

    def match_file_name(self, name):
        match = Parser.regex.match(name)
        return match

    def parse(self):
        try:
            extention = os.path.splitext(self.entry.name)[1]
            if extention.lower() == ".zip":
                match = self.match_file_name(self.entry.name)
                if not match:
                    raise Error1('Filename parsing error: {}'.format(
                        self.entry.name)
                        )
            self.result = {x: match.group(x) for x in self.groups}
            return self.result
        except Exception as err:
            raise Error1 ("Non-zip file in Incoming folder: '{}'".format(self.entry.name))

    def process(self, config):
        self.groups = ['product', 'study', 'vendor', 'labtest', 'rcvdate',
                       'invsite', 'results', 'additional', 'extension']
        if not Parser.regex:
            Parser.regex = self.get_regex(config.basic['Labtest'])
        return self.parse()


###############################################################################
# STEP: TRANSLATE
###############################################################################
class Translator(PipelineStepInterface):
    def translate_product(self, parsed_product):
        return parsed_product.upper()

    def translate_study(self, study):
        return study

    def translate_vendor(self, vendor):
        return vendor

    def translate_labtest(self, labtest):
        return labtest

    def translate_invsite(self, invsite):
        return "-invsite" if invsite else ""

    def translate_results(self, labtest, results):
        labtests = labtest.split("_")
        if 'result' in labtests:  # also catches 'results' in labtests
            return "-results"
        elif results:
            return "-results"
        else:
            return ""

    def translate_rcvdate(self, rcvdate):
        rcvdate_out = rcvdate.lower()
        for i, j in enumerate(['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul',
                              'aug', 'sep', 'oct', 'nov', 'dec']):
            rcvdate_out = rcvdate_out.replace(j, "%02d" % (i+1))
        if len(rcvdate_out) == 6:
            rcvdate_out = "20" + rcvdate_out
        if not rcvdate_out.isdigit():
            raise ValueError("Cannot translate date: {}".format(rcvdate))
        return rcvdate_out

    def translate_extension(self, extension):
        return extension.lower()

    def translate_other(self, other):
        return other

    def translate(self):
        try:
            return {
                'product': self.translate_product(
                        self.past_results['product']
                    ),
                'study': self.translate_study(
                        self.past_results['study'],
                    ),
                'vendor': self.translate_vendor(
                        self.past_results['vendor']
                    ),
                'labtest': self.translate_labtest(
                        self.past_results['labtest']
                    ),
                'invsite': self.translate_invsite(
                        self.past_results['invsite']
                    ),
                'results': self.translate_results(
                        self.past_results['labtest'],
                        self.past_results['results'],
                    ),
                'rcvdate': self.translate_rcvdate(
                        self.past_results['rcvdate']
                    ),
                'extension': self.translate_extension(
                        self.past_results['extension']
                    ),
                'additional': self.translate_other(
                        self.past_results['additional']
                    ),
                }
        except Exception as err:
            raise Error1("Translate Error: {}".format(err))

    def process(self, config):
        self.config = config
        return self.translate()


###############################################################################
# STEP: VALIDATE
###############################################################################
class Validator(PipelineStepInterface):
    def validate_product_study_vendor(self, product, study, vendor):
        try:
            flag = False
            for values in self.config.product.values():
                for value in values.values():
                    if value['product'] == product and value['study'] == study and value['vendor'] == vendor:
                        flag = True
            if flag == False:
                raise KeyError
        except KeyError as err:
            msg = "Validate: This Product '{}', Study '{}' and Vendor '{}' combination not found in product config."
            msg = msg.format( product, study, vendor)
            raise Error1(msg)

    def validate_other(self, other):
        if len(other) > 0:
            msg = "Additional info at end of filename: '{}'".format(
                    other)
            self.logger.warning(msg)

    def validate(self):
        try:
            # The following will throw exceptions if validation failes
            self.validate_product_study_vendor(
                self.past_results['product'],
                self.past_results['study'],
                self.past_results['vendor'])
                #,self.past_results['filename'])
            
            self.validate_other(self.past_results['additional'])
            # If all validateions pass without raising exceptions, propagate the
            # translated results to the next pipeline step.
            return self.past_results
        except Exception as err:
            raise Error1("Validate Error: {}".format(err))

    def process(self, config):
        self.config = config
        return self.validate()


###############################################################################
# STEP: MOVE
###############################################################################
class Mover(PipelineStepInterface):

    def process_initializer(self):
        self.product = self.past_results["product"]
        self.study = self.past_results["study"]
        self.vendor = self.past_results["vendor"]
        self.invsite = self.past_results["invsite"]
        self.results = self.past_results["results"]
        self.rcvdate = self.past_results["rcvdate"]

    def unzip_file(self, src):
        try:
            for file_name in os.listdir(src):
                full_file_name = os.path.join(src, file_name)
                extention = os.path.splitext(full_file_name)[1]
                if extention.lower() == ".zip":
                    with zipfile.ZipFile(full_file_name, 'r') as zip_ref:
                        zip_ref.extractall(src)
                        self.logger.info("Zip file unzipped: {}".format(
                            ", ".join(zip_ref.namelist())))
        except Exception as err:
            raise zipfile.BadZipfile("Could not unzip file '{}'. Revceived message '{}'\
                    ".format(file_name, err))

    def dir_generator(self, base_folder):
        dir_name = os.path.join("./{}".format(base_folder), self.product,
                                self.study, "lab", self.vendor)
        return dir_name

    def subdir_generator(self):
        #base_dir = self.config.product[self.product][self.study, self.vendor]['path']
        for count in self.config.product.values():
            for count1 in count.values():
                if count1['product'] == self.product and count1['study'] == self.study and count1['vendor'] == self.vendor:
                    base_dir = count1['path']
                    break
        if base_dir == '':
            raise Error2("'Path' does not exist.")
        else:
            base=".{}".format(base_dir)
            name=FileUtil.dir_name_generator(self)
            sub_dir_temp = os.path.join(base, name)
            sub_dir=sub_dir_temp.replace("\\", "/" )

        if not os.path.exists(sub_dir):
            FileUtil.create_dir(sub_dir)
        return sub_dir

    def move_intermediate(self):
        try:
            sub_dir = self.subdir_generator()
            FileUtil.create_dir(self, sub_dir)
            self.logger.warning("Creating CDM Target Directory: {}"
                                .format(sub_dir))
            FileUtil.move_file(self, self.entry.path, sub_dir)
            self.unzip_file(sub_dir)
            return sub_dir
        except Exception as err:
            raise Error1("Error in Mover: {}".format(err))

    def process(self, config):
        self.config = config
        self.result = self.past_results
        self.process_initializer()
        self.result['sub_dir'] = self.move_intermediate()
        return self.result


###############################################################################
# STEP: CHECK
###############################################################################
class Checker(PipelineStepInterface):
    def process_initializer(self):
        self.product = self.past_results["product"]
        self.study = self.past_results["study"]
        self.vendor = self.past_results["vendor"]
        self.invsite = self.past_results["invsite"]
        self.results = self.past_results["results"]
        self.rcvdate = self.past_results["rcvdate"]
        self.sub_dir = self.past_results["sub_dir"]
                
    def create_log_dir(self):
        config_base=self.config.basic['Check']['CheckLogFileBasePath']       
        log_dir=config_base + self.sub_dir
        FileUtil.create_dir(self, log_dir)  
        return log_dir
    
    
    def run_SAS_prog(self, file_path):                  # u have log_dir,ssdpath,prog_path,program name
        # TODO: there is no file path or no program path
        pass 
        #subprocess.call(["gsas",file_path, self.log_dir])
        
        
    def run_files(self):
        try:
            self.test_count=0
            for file_name in os.listdir(self.sub_dir):
                full_file_name = os.path.join(self.sub_dir, file_name)
                extention = os.path.splitext(full_file_name)[1]
                if extention.lower() != ".zip":
                    self.sas_program_path =self.config.product[self.product, self.study, self.vendor][os.path.splitext(file_name)[0]]['sas program path']
                    self.test_counter(file_name)
                    #self.run_SAS_prog(self,os.path.splitext(full_file_name))                          # Call SAS program
        except Exception as err:
            raise Exception("Error while configuring and calling SAS prog: {}".format(err))
            
    def test_counter(self, file_name):
        for test_name in (self.config.basic['Check']['CheckProgramColumns']).split(","):            # checkProgramconfig contains the data from config file with test names
            if (self.config.product[self.product, self.study, self.vendor][
                os.path.splitext(file_name)[0]][test_name]).upper() == 'Y':
                    self.test_count += 1
        
    def output_file_verifier(self):
        if self.test_count != len(os.listdir(self.log_dir)):
            raise Exception("Did not run all the test")
        
    def check_files(self):
        try:
            self.log_dir=self.create_log_dir()               # will pass this dir to SAS prog maybe
            self.run_files()
            self.output_file_verifier()
        except Exception as err:
            raise Error1("Error in Checker: {}".format(err))
            
    # setting Config ,calling process initializer ,calling main prog
    def process(self, config):
        self.config = config
        self.process_initializer()
        self.past_results['log_dir'] = self.check_files()
        return self.past_results


###############################################################################
# STEP: PUBLISH
###############################################################################
class Publisher(PipelineStepInterface):

    def process_initializer(self):
        self.product = self.past_results["product"]
        self.study = self.past_results["study"]
        self.vendor = self.past_results["vendor"]
        self.invsite = self.past_results["invsite"]
        self.results = self.past_results["results"]
        self.rcvdate = self.past_results["rcvdate"]
        self.sub_dir = self.past_results["sub_dir"]

    def copy_file(self):
        for file_name in os.listdir(self.sub_dir):
            full_file_name = os.path.join(self.sub_dir, file_name)
            extention = os.path.splitext(full_file_name)[1]
            if extention.lower() != ".zip":
                destdir = self.dest_dir_generator(file_name)
                FileUtil.create_dir(self, destdir)
                sub_dir=full_file_name.replace("\\", "/" )
                FileUtil.move_file(self, sub_dir, destdir)                 # move(filelocation+name,destLocation)

    def dest_dir_generator(self, file_name):
        dest_dir = self.config.product[self.product, self.study, self.vendor][os.path.splitext(file_name)[0]]['ssdpath']        #Take ssdpath
        if dest_dir == '':
            raise Exception(" 'SSDPATH' Directory does not exist ")              # check if exist if no throw error
        destdir = os.path.join(".{}".format(dest_dir))
        return destdir

    def move_target(self):
        try:
            self.copy_file()
        except Exception as err:
            raise Error2(" CTSHARED Target Directory does not exist "+str(err))
    def process(self, config):
        self.config = config
        self.process_initializer()
        self.move_target()
        return self.past_results

###############################################################################
# Finisher
###############################################################################
class Finisher(PipelineStepInterface):
    def process_initializer(self):
        self.study = self.past_results["study"]

    def run_sas_prog():
        #Path needs to be taken from csv file, or it an be hardcoded. Ask Robert.
        # TODO:SAS Program Call
        # subprocess.call(["gsas", path, self.study])
        pass

    def process(self, config):
        self.config = config
        self.process_initializer()
        self.run_sas_prog()
        return self.past_results
    
###############################################################################
# Email
###############################################################################
class Emailer(CdiObject):
    def __init__(self):
        ''' TODO: Setup for smtp email '''
        super().__init__()

    def email_log(self, email_config, session_log):
        to = email_config["To"]
        cc = email_config["Cc"]
        bcc = email_config["Bcc"]
        msg = "TODO: Implement Send Email (len={}) to: {} cc:{} bcc:{}".format(
                len(session_log), to, cc, bcc)
        self.logger.warning(msg)

###############################################################################
# Main
###############################################################################
if __name__ == '__main__':
    session_log = StringIO()
    with CaptureLogging(session_log) as logging_session:
        try:
            config = ConfigReaderValidator().read_config(
                    DEFAULT_CONFIG_FILENAME)
            logging_session.initialize_file_logging(
                    config.basic['General']['LogFilePath'])
            logging_session.update_log_level(
                    config.basic['General'].get('LogLevel', DEFAULT_LOG_LEVEL))
            logging_session.logger.info('Launching.')
            pipeline = Pipeline(config)
            pipeline.execute_pipeline([
                Parser,
                Translator,
                Validator,
                Mover,
                #Checker,
                Publisher,
                Finisher,
            ])
            logging_session.logger.info("Done.")
            Emailer().email_log(config.basic["Email"], session_log.getvalue())
        except Error0 as err:
            ''' Error already logged when Error0 thrown. '''
