# -*- coding: utf-8 -*-
"""
Created on Mon May 15 11:51:46 2017

@author: dnathani
"""

import sklearn as sk

features=[[140,1],[130,1],[150,0],[170,0]]

labels=[0,0,1,1]

clf=sk.tree.DecisionTreeClassifier()

clf=clf.fit(features,labels)

print(clf.predict([[150,0]]))