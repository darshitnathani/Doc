# -*- coding: utf-8 -*-
"""
Created on Tue Aug 01 17:58:14 2017

@author: dnathani
"""

from sklearn.tree import DecisionTreeClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def buyingPriceFormating(data):
    if data=="vhigh":
        return 1
    elif data=="high":
        return 2
    elif data=="med":
        return 3
    else:
        return 4
    
def maintenancepriceFormating(data):
    if data=="vhigh":
        return 1
    elif data=="high":
        return 2
    elif data=="med":
        return 3
    else:
        return 4
    
def doorsFormating(data):
    if data=="2":
        return 2
    elif data=="3":
        return 3
    elif data=="4":
        return 4
    else:
        return 5
    
    
def personsFormating(data):
    if data=="2":
        return 2
    elif data=="4":
        return 4
    else:
        return 7
    
    
def lugBootFormating(data):
    if data=="small":
        return 1
    elif data=="med":
        return 2
    else:
        return 3
    
def safetyFormating(data):
    if data=="low":
        return 1
    elif data=="med":
        return 2
    else:
        return 3

def classFormating(data):
    if data=="unacc":
        return 1
    elif data=="acc":
        return 2
    elif data=="good":
        return 3
    else:
        return 4

def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("careval.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            temp2.append(buyingPriceFormating(newLine[0]))
            temp2.append(maintenancepriceFormating(newLine[1]))
            temp2.append(doorsFormating(newLine[2]))
            temp2.append(personsFormating(newLine[3]))
            temp2.append(lugBootFormating(newLine[4]))
            temp2.append(safetyFormating(newLine[5]))
            temp=newLine[6].split("\n")
            dataResult.append(classFormating(temp[0]))
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    print(Result)
    return Result


irisData=dataSetNo1()

TData=[]
RData=[]

for data in irisData:
    TData.append(data[0])
    RData.append(data[1])
print(TData)
print(RData)

trainingDataX=[]
trainingDataY=[]
trainingDataP=[]
trainingDataQ=[]

for data in TData:
    trainingDataX.append(data[0])
    trainingDataY.append(data[1])
    trainingDataP.append(data[2])
    trainingDataQ.append(data[3])
    
trainer=DecisionTreeClassifier()

trainer=trainer.fit(TData,RData)

print(trainer.predict([4,4,5,7,3,3]))

#print(trainer.predict([5.9, 3.0, 5.1, 1.8]))

#dataTest=trainer.predict([5.1, 3.5, 1.4, 0.2])

#
#if(dataTest==0):
#    print("Selected Flower is setosa")
#elif(dataTest==1):
#    print("Selected Flower is versicolor")
#else:
#    print("Selected Flower is virginica")
#plt.figure(num=1)
#plt.scatter(trainingDataX, trainingDataY,c=RData)
#plt.figure(num=2)
#plt.scatter(trainingDataP, trainingDataQ,c=RData)
#plt.figure(num=3)
#plt.scatter(trainingDataY, trainingDataP,c=RData)
#plt.figure(num=4)
#plt.scatter(trainingDataX, trainingDataQ,c=RData)
#plt.figure(num=5)
#plt.scatter(trainingDataX, trainingDataP,c=RData)
#plt.figure(num=6)
#plt.scatter(trainingDataY, trainingDataQ,c=RData)