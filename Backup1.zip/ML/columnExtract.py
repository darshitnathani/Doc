# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 14:33:17 2017

@author: dnathani
"""

import pandas as pd
import json

df = pd.read_csv("creditcard.csv")
saved_column = df["V2"].values #you can also use df['column_name']
print(saved_column)

names=['Time', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10', 'V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19', 'V20', 'V21', 'V22', 'V23', 'V24', 'V25', 'V26', 'V27', 'V28', 'Amount', 'Class']

columnResults=[]
for data in names:
    columnResults.append(df[data].values)

new_col_result=[]
for data in columnResults:
    temp=[]
    for data_inside in data:
        temp.append(float(data_inside))
    new_col_result.append(temp)
count=0
results=[]
for data in new_col_result:
    results.append({names[count]:data})
    count += 1

result = {"data": results}
output=json.dumps(result)