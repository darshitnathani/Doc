# -*- coding: utf-8 -*-
"""
Created on Tue Sep 05 19:52:36 2017

@author: dnathani
"""
import pickle
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import RFE


def dataSetTest():

    inputData=[]
    dataResult=[]
    #datapath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials\PYUI\templates\Uploads","filename-1504081951078.csv")
    #fobj=open(datapath,"r") 
    fobj=open("creditcardTest.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,30):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[30].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    
    return Result
    

testData=dataSetTest()

    
TestTData=[]
TestRData=[]

for data in testData:
    TestTData.append(data[0])
    TestRData.append(data[1])
    
filename = 'CreditCardModleDT.sav'
    
# load the model from disk
loaded_model = pickle.load(open(filename, 'rb'))
prediction2=loaded_model.predict(TestTData)
accNew=accuracy_score(TestRData,prediction2)
data=loaded_model.predict([172583,-0.396918844,0.487681002,1.749180161,-0.448275539,0.073370105,-0.154573775,0.441296263,-0.053160026,0.350395219,-0.337734941,0.838187658,0.431894088,-0.695062593,-0.007505928,-0.032102349,0.007546238,-0.672374037,0.447118913,0.538019995,-0.06238808,-0.073548184,-0.043524345,-0.003460215,-0.035273194,-0.710456038,-0.638312219,-0.107173342,-0.048507421,5])
print(data)
print(accNew)


# save the model to disk
filename = 'CreditCardModleDTREF.sav'
#pickle.dump(rfe, open(filename, 'wb'))


loaded_model_REF = pickle.load(open(filename, 'rb'))

#rfe = RFE(loaded_model, 3)
#rfe = rfe.fit(TestTData, TestRData)
storeValidity=loaded_model_REF.support_
storeRank=loaded_model_REF.ranking_
print(loaded_model_REF.support_)
print(loaded_model_REF.ranking_)
