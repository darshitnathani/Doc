# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 20:16:02 2017

@author: dnathani
"""

import seaborn as sns
import numpy as np
x = np.random.normal(size=100)
sns.distplot(x);