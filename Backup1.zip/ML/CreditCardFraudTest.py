# -*- coding: utf-8 -*-
"""
Created on Fri Sep 01 08:40:01 2017

@author: dnathani
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
import seaborn as sns
from Tkinter import StringVar
from Tkinter import Tk
from Tkinter import Label
from Tkinter import OptionMenu
from Tkinter import Button
import tkMessageBox
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import datasets
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score

def dataSetNo1():

    inputData=[]
    dataResult=[]
    fobj=open("creditcard - Copy.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,30):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[30].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    
    return Result

def dataSetTest():

    inputData=[]
    dataResult=[]
    fobj=open("creditcardTest.csv","r")              
    
    count=0
    index=0
    for line in fobj:
        newLine=line.split(",")
        
        if index!=0:
            temp=[]
            temp2=[]
            for dataindex in range(0,30):
                temp2.append(float(newLine[dataindex]))
            temp=newLine[30].split("\n")
            dataResult.append(temp[0])
            inputData.append(temp2)
            count=count+1
        index=index+1  

    
    fobj.close()
    Result=zip(inputData,dataResult)
    
    return Result


def training_model():
    creditCard=dataSetNo1()
    
    TData=[]
    RData=[]
    
    for data in creditCard:
        TData.append(data[0])
        RData.append(data[1])
        
    trainer=DecisionTreeClassifier()
    trainer2=KNeighborsClassifier()
    
    print([trainer,trainer2])
    
    return [trainer,trainer2]
    
def trained_test(data):
    
    testData=dataSetTest()
    TestTData=[]
    TestRData=[]
    
    for data in testData:
        TestTData.append(data[0])
        TestRData.append(data[1])
        
    prediction=trainer.predict(TestTData)
    acc1=accuracy_score(TestRData,prediction)
    
    prediction2=trainer2.predict(TestTData)
    acc2=accuracy_score(TestRData,prediction2)
    
    
    print(acc1*100)
    print(acc2*100)