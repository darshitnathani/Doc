# -*- coding: utf-8 -*-
"""
Created on Mon Oct 02 12:26:03 2017

@author: darshit.nj
"""

from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
trainer=DecisionTreeClassifier()
trainer2=KNeighborsClassifier()

Training_data=[[1,0,55],[1,1,25],[0,0,63],[0,1,23],[0,0,43],[0,0,60],[0,1,25]]
Training_result=["Yedaaa","Yedaaa","NoYedaaa","Yedaaa","Yedaaa","NoYedaaa","NoYedaaa"]

trainer.fit(Training_data,Training_result)
trainer2.fit(Training_data,Training_result)
print(trainer.predict([1,0,53]))
print(trainer2.predict([1,0,53]))