# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 22:32:12 2017

@author: darshit.nj
"""

# Feature Importance
from sklearn import datasets
from sklearn import metrics
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
# load the iris datasets
dataset = datasets.load_iris()
# fit an Extra Trees model to the data
model = DecisionTreeClassifier()
model.fit(dataset.data, dataset.target)
# display the relative importance of each attribute
print(model.feature_importances_)
print(model.feature_importances_)