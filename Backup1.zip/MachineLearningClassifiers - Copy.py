# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 14:39:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 14:49:47 2017

@author: dnathani
"""

import flask
from flask import request
import os
from flask import Flask
import numpy as np
from sklearn.metrics import accuracy_score
import pickle
import json
import csv



trainer = pickle.load(open("../CreditCardModleDT.sav", 'rb'))
trainer2 = pickle.load(open("../CreditCardModleKNN.sav", 'rb'))

app = Flask(__name__, static_url_path="", static_folder="static")

Training=50
Testing=50
Hold=0

@app.route('/splitData', methods=['POST'])    
def Split():
    input_json = request.get_json(force=True)  
    print(input_json)
    Training=input_json["Training"]
    Testing=input_json["Testing"]
    Hold=input_json["Hold"]
    
    print(Training,Testing,Hold)
    split_Data(Training,Testing,Hold)
    
    return "Data Splited Succesfully"

def split_Data(Training,Testing,Hold):
    filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials","creditcard.csv")
    
    with open(filepath,"r") as f:
            reader = csv.reader(f,delimiter = ",")
            columns=reader.next()
            print(columns)
            data = list(reader)
            row_count = len(data)
            trainEnd=int(((row_count*Training)+1)/100)
            testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
            randomList=np.random.randint(1,row_count,size=row_count)
            trainingData=[]
            testingData=[]
            for data in range(0,trainEnd):
                trainingData.append(randomList[data])
            for data in range(trainEnd,testEnd):
                testingData.append(randomList[data])
                
            print(len(trainingData),len(testingData))
      
    with open(filepath,"r") as f:
            rowsData=[]
            reader = csv.reader(f,delimiter = ",")
            for row in reader:
                rowsData.append(row)
               
            Training_data=[]
            Testing_data=[]
            
            for data in trainingData:
                Training_data.append(rowsData[data])
                
            
            for data in testingData:
                Testing_data.append(rowsData[data])
            
            TrainingDataResult=[]
            TrainingInputData=[]
            for newLine in Training_data:
                    temp2=[]
                    for dataindex in range(0,(len(columns)-1)):
                        temp2.append(float(newLine[dataindex]))
                    TrainingDataResult.append(int(newLine[len(columns)-1]))
                    TrainingInputData.append(temp2)
                    
                    
            TestingDataResult=[]
            TestingInputData=[]
            for newLine in Testing_data:
                    temp2=[]
                    for dataindex in range(0,(len(columns)-1)):
                        temp2.append(float(newLine[dataindex]))
                    TestingDataResult.append(int(newLine[len(columns)-1]))
                    TestingInputData.append(temp2)
                    
    
    return "Done"
    
@app.route('/accTest/<filename>')    
def trained_test(filename):
    
    testData=dataSetTest(filename)
    TestTData=[]
    TestRData=[]
    
    for data in testData:
        TestTData.append(data[0])
        TestRData.append(data[1])
        
    prediction=trainer.predict(TestTData)
    acc1=accuracy_score(TestRData,prediction)
    
    prediction2=trainer2.predict(TestTData)
    acc2=accuracy_score(TestRData,prediction2)
    
    
    print(acc1*100)
    print(acc2*100)
    result={"Modle1Acc": acc1*100, "Modle2Acc": acc2*100}
    return json.dumps(result)
    

@app.route('/predict')    
def prredict_result():
    
    testData=dataSetTest()
    TestTData=[]
    TestRData=[]
    
    for data in testData:
        TestTData.append(data[0])
        TestRData.append(data[1])
        
    prediction=""
    print(prediction)
    
    prediction2=trainer2.predict(TestTData)
    acc2=accuracy_score(TestRData,prediction2)
    
    return "TODO"


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"



@app.route('/')
def hello_world():
    #return flask.render_template('index.html')
    return "ML.html"

@app.route('/machineLearning')
def machine_learning():
    return flask.render_template('ML.html')

if __name__ == '__main__':
    configuration = Configuration()
    configuration.proxies()
    app.run('0.0.0.0',1612)