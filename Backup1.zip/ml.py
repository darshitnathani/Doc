# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 22:30:15 2017

@author: darshit.nj
"""

# Recursive Feature Elimination
from sklearn import datasets
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
# load the iris datasets
dataset = datasets.load_iris()
# create a base classifier used to evaluate a subset of attributes
model = DecisionTreeClassifier()
# create the RFE model and select 3 attributes
rfe = RFE(model, 2)
rfe = rfe.fit(dataset.data, dataset.target)
model = model.fit(dataset.data, dataset.target)
# summarize the selection of the attributes
print(model.feature_importances_)
print(rfe.support_)
print(rfe.ranking_)