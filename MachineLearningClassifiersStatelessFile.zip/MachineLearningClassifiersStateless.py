# -*- coding: utf-8 -*-
"""
Created on Tue Sep 19 17:08:24 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 15:13:22 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 11:58:02 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep 06 14:39:48 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 14:49:47 2017

@author: dnathani
"""

from flask import request
import os
from flask import session
from flask import Flask
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_recall_fscore_support
import pandas as pd
import pickle
import json
import csv
import random


###############################################################################
#Configuration
###############################################################################


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"

###############################################################################
#Flask Configuration
###############################################################################
        
        
app = Flask(__name__, static_url_path="", static_folder="static")
app.secret_key = os.urandom(24)

###############################################################################
#Global Variables
###############################################################################

faltudata=[]

def reset_Data():
    session['columns']=[]
    session['rowsData']=[]
    session['FileData']=[]
    session['FileResult']=[]
    session['attributeValidity']=[]
    session['rowNumber']=0
    session['FileName']=""
    session['Training_data']=[]
    session['Testing_data']=[]
    session['Training_Result']=[]
    session['Testing_Result']=[]
    session['Filtered_traning_data']=[]
    session['finalAttributes']=[]
    session['FinalAttributeCount']=0
    session['Filtered_testing_data']=[]
    session['DT_accuracy']=0
    session['KNN_accuracy']=0
    session['data_Faltu1']=[]
    session['data_Faltu2']=[]
    session['UniqueList']=[]
    
###############################################################################
#Training
###############################################################################
#******************************************************************************
#Attribute Selection (First Call)
#******************************************************************************
def isfloat(value):
  try:
    float(value)
    return True
  except ValueError:
    return False

@app.route('/dataset/split')
def attribute_selection():
    try:
        reset_Data()
        FileName =  request.args.get('file') + ".csv"
        Training = int(request.args.get('Training'))
        Testing = int(request.args.get('Testing'))
        Hold = int(request.args.get('Hold'))
        return json.dumps({"Configuration":[{"FileName": FileName, "Training": Training, "Testing": Testing, "Hold": Hold}]})
    except Exception as err:
        return "Invalid Key or Missing data in Input Json, stack error: {}".format(err)

@app.route('/dataset/getAttributes', methods=['POST'])
def getAttribute():
    try:
        input_json = request.get_json(force=True)
        Filename = input_json["Configuration"][0]["FileName"]
        Training = input_json["Configuration"][0]["Training"]
        Testing = input_json["Configuration"][0]["Testing"]
        
        filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",Filename)
        with open(filepath,"r") as f:
                reader = csv.reader(f,delimiter = ",")
                columns=reader.next()
                rowsData=[]
                rowNumber=0
                FileResult=[]
                FileData=[]
                for row in reader:
                    rowsData.append(row)
                    rowNumber = rowNumber + 1
                    
                for newLine in rowsData:
                    temp2=[]
                    for dataindex in range(0,(len(columns)-1)):
                        if isfloat(newLine[dataindex]):
                            temp2.append(float(newLine[dataindex]))
                        else:
                            temp2.append(0.0)
                    if isfloat(newLine[len(columns)-1]):
                        FileResult.append(int(newLine[len(columns)-1]))
                    else:
                        raise Exception("Last Column should be Binary or integer Classification Data")
                    FileData.append(temp2)
        invalidColumn=[]
        for data in range(0,len(FileData[0])):
            count=0
            for data2 in range(0,len(FileData)):
                count +=FileData[data2][data]
            if count == 0.0:
                for data2 in range(0,len(FileData)):
                    del FileData[data2][data]
                invalidColumn.append(data)
                del columns[data]
                
            
        model = LogisticRegression()
        rfe = RFE(model, int(len(columns)*0.4))
        rfe = rfe.fit(FileData, FileResult)
        attributeValidity=rfe.support_.tolist()
        
        filepath=os.path.join(r"C:\Users\dnathani\Desktop\FFT_Trials\ML Trials",Filename)
        with open(filepath,"r") as f:
                reader = csv.reader(f,delimiter = ",")
                columns = reader.next()
                data = list(reader)
                row_count = len(data)
                trainEnd=int(((row_count*Training)+1)/100)
                testEnd=int(int((row_count*Training)+1+int(row_count*Testing)+1)/100)
                randomList=random.sample(range(1,row_count), row_count-1)
                trainingData=[]
                testingData=[]
                for data in range(0,trainEnd):
                    trainingData.append(randomList[data])
                for data in range(trainEnd+1,testEnd):
                    testingData.append(randomList[data])
                 
        with open(filepath,"r") as f:
                rowsData=[]
                reader = csv.reader(f,delimiter = ",")
                for row in reader:
                    rowsData.append(row)
                Training_data=[]
                Training_Result=[]
                Testing_data=[]
                Testing_Result=[]           
                for data in trainingData:
                    Training_data.append(FileData[data])
                    Training_Result.append(FileResult[data])
                    
                for data in testingData:
                    Testing_data.append(FileData[data])
                    Testing_Result.append(FileResult[data])
                
                
                for data in invalidColumn:
                    del columns[data]
                
                df = pd.read_csv(filepath)
                
                columnResults=[]
                for data in columns:
                    columnResults.append(df[data].values)
                global faltudata    
                for data in columns:
                    faltudata.append(df[data].values)
                
                print(faltudata)
                
                
                new_col_result=[]
                invalid_rows=set()
                
                for data in columnResults:
                    temp=[]
                    count=0
                    for data_inside in data:
                        if isfloat(data_inside):
                            temp.append(float(data_inside))
                        else:
                            temp.append(0.0)
                            invalid_rows.add(count)
                        count += 1
                    new_col_result.append(temp)
                
                print(new_col_result)
                print(invalid_rows)
                
#                for data in invalid_rows:
#                    del columns[data]
                    
                newAttributeValidity=attributeValidity
                groupingData=range(0,len(columns)-1)
                groupingData.append(0)
                uniqueData=set()
                for data in new_col_result[len(columns)-1]:
                    uniqueData.add(data)
                UniqueList=list(uniqueData)
                
                
                group=[]
                for data in range(0,len(columns)-1):
                    group.append(zip(new_col_result[groupingData[data]],new_col_result[groupingData[data+1]]))
                colorData=[]
                for data in range(0,len(columns)):
                    tempColor=[]
                    tempColor.append(int(random.random()*255))
                    tempColor.append(int(random.random()*255))
                    tempColor.append(int(random.random()*255))
                    colorData.append(tempColor)    
                results=[]
                
#                for data in range(0,len(new_col_result[len(columns)-1])):
#                    print(len(group[0][data]))
#                    print(group[0][data])
#                    print(len(group[1][data]))
#                    print(group[1][data])
#                    print(len(group[3][data]))
#                    print(group[2][data])
#                    print(len(group[3][data]))
#                    print(group[3][data])
                    
                try:
                    for columnIndex in range(0,len(columns)-1):
                            tempJsonData=[]
                            colorCount=0
                            for classificationData in UniqueList:
                                mesData=[]
                                for data in range(0,len(new_col_result[len(columns)-1])):
                                    if new_col_result[len(columns)-1][data] == classificationData:
                                        mesData.append(group[columnIndex][data])
                                tempColorData="rgba({}, {}, {}, .5)".format(colorData[colorCount][0],colorData[colorCount][1],colorData[colorCount][2])        
                                tempJsonData.append({"Classification":classificationData,"Measurment":mesData,"color":tempColorData})
                                colorCount += 1
                            results.append({"attributeName":columns[columnIndex],"attributeData":tempJsonData,"Relevance":newAttributeValidity[columnIndex]})
                    AttributeDataJson = {"data": results,"Configuration":[{"FileName": Filename,"columns": columns, "rowNumber": rowNumber, "Training_data": Training_data, "Training_Result": Training_Result, "Testing_data": Testing_data, "Testing_Result": Testing_Result, "UniqueList":UniqueList}]}
                except Exception as err:
                    raise Exception("There is some unexpeted character in your CSV or CSV data is in incompatible format.")               
        return json.dumps(AttributeDataJson)
    except Exception as err:
        return "Error while Generating attributes,stack error '{}'".format(err)

#******************************************************************************
#Filter Data According to Selected Attributes
#******************************************************************************

@app.route('/dataset/sendAttributes', methods=['POST'])    
def filter_data():
    try:
        input_json = request.get_json(force=True)
        
        Filename = input_json["Configuration"][0]["FileName"]
        columns = input_json["Configuration"][0]["columns"]
        rowNumber = input_json["Configuration"][0]["rowNumber"]
        Training_data = input_json["Configuration"][0]["Training_data"]
        Training_Result = input_json["Configuration"][0]["Training_Result"]
        Testing_data = input_json["Configuration"][0]["Testing_data"]
        Testing_Result = input_json["Configuration"][0]["Testing_Result"]
        UniqueList = input_json["Configuration"][0]["UniqueList"]
        
        
        Jsonkeys=input_json["data"][0].keys()
        finalAttributes=[]
        FinalAttributeCount=0
        for data in columns:
            if data in Jsonkeys:
                if input_json["data"][0][data]:
                    finalAttributes.append(data)
                    FinalAttributeCount += 1
        Filtered_traning_data=[]            
        for data in Training_data:
            temp=[]
            for columnData in finalAttributes:
                temp.append(data[columns.index(columnData)])
            Filtered_traning_data.append(temp) 
        Filtered_testing_data=[] 
        for data2 in Testing_data:
            temp2=[]
            for columnData in finalAttributes:
                temp2.append(data2[columns.index(columnData)])
            Filtered_testing_data.append(temp2)  
            
         
        return json.dumps({"Configuration":[{"FileName": Filename,
                                             "columns": columns,
                                             "rowNumber": rowNumber,
                                             "Training_data": Training_data,
                                             "Training_Result": Training_Result,
                                             "Testing_data": Testing_data,
                                             "Testing_Result": Testing_Result,
                                             "UniqueList":UniqueList,
                                             "finalAttributes":finalAttributes,
                                             "FinalAttributeCount":FinalAttributeCount,
                                             "Filtered_traning_data":Filtered_traning_data,
                                             "Filtered_testing_data":Filtered_testing_data
                                             }]})
    except Exception as err:
        return "Error while Fitering Attributes ,stack error {}".format(err)    
#******************************************************************************
#Train Decision Tree
#******************************************************************************

@app.route('/dataset/trainModel', methods=['POST'])    
def train_dicision_tree():
    try:
        input_json = request.get_json(force=True)   
        Filename = input_json["Configuration"][0]["FileName"]        
        columns = input_json["Configuration"][0]["columns"]
        rowNumber = input_json["Configuration"][0]["rowNumber"]
        Training_data = input_json["Configuration"][0]["Training_data"]
        Training_Result = input_json["Configuration"][0]["Training_Result"]
        Testing_data = input_json["Configuration"][0]["Testing_data"]
        Testing_Result = input_json["Configuration"][0]["Testing_Result"]
        UniqueList = input_json["Configuration"][0]["UniqueList"]
        finalAttributes = input_json["Configuration"][0]["finalAttributes"]
        FinalAttributeCount = input_json["Configuration"][0]["FinalAttributeCount"]
        Filtered_traning_data = input_json["Configuration"][0]["Filtered_traning_data"]
        Filtered_testing_data = input_json["Configuration"][0]["Filtered_testing_data"]
        classifierName = request.args.get('classifier')
        sampleRowData=[]
        for data in Filtered_traning_data[len(Filtered_traning_data)-1]:
            sampleRowData.append(data)
        sampleRowData.append(Training_Result[len(Training_Result)-1])
        if classifierName.lower() == "decisiontree_classifier":
            trainerDT=DecisionTreeClassifier()
            trainerDT=trainerDT.fit(Filtered_traning_data,Training_Result)
            pickle.dump(trainerDT, open(os.path.splitext(Filename)[0]+".sav", 'wb'))
            loaded_model_DT = pickle.load(open(os.path.splitext(Filename)[0]+".sav", 'rb'))
            prediction_DT=loaded_model_DT.predict(Filtered_testing_data)
            DT_accuracy=0
            DT_accuracy += accuracy_score(Testing_Result,prediction_DT)
            precisionDataDT=precision_recall_fscore_support(Testing_Result, prediction_DT)[0].tolist()
            precisionDT=[]
            for data in precisionDataDT:
                precisionDT.append(data/(sum(precisionDataDT)))
            finalAttributes.append("Result")
            training_result={"accuracy":DT_accuracy*100,"totalNumberOfRows":rowNumber,"numberOfRowsForTraining":len(Training_data),"numberOfRowsForTesting":len(Testing_data),"totalNumberOfAttributes":len(columns)-1,"numberOfAttributesUsed":FinalAttributeCount,"rowData":sampleRowData,"columnData":finalAttributes,"classifier":"DecisionTree_Classifier","classification":UniqueList,"Precision":precisionDT,"Filename":Filename}
            return json.dumps(training_result)
        if classifierName.lower() == "knn_classifier":    
            trainerKNN=KNeighborsClassifier()
            trainerKNN=trainerKNN.fit(Filtered_traning_data,Training_Result)
            pickle.dump(trainerKNN, open(os.path.splitext(Filename)[0]+".sav", 'wb'))
            loaded_model_KNN = pickle.load(open(os.path.splitext(Filename)[0]+".sav", 'rb'))
            prediction_KNN=loaded_model_KNN.predict(Filtered_testing_data)
            Training_Result =0
            Training_Result =accuracy_score(Testing_Result,prediction_KNN)
            precisionDataKNN=precision_recall_fscore_support(Testing_Result, prediction_KNN)[0].tolist()
            precisionKNN=[]
            for data in precisionDataKNN:
                precisionKNN.append(data/(sum(precisionDataKNN)))
            training_result={"accuracy":Training_Result*100,"totalNumberOfRows":rowNumber,"numberOfRowsForTraining":len(Training_data),"numberOfRowsForTesting":len(Testing_data),"totalNumberOfAttributes":len(columns)-1,"numberOfAttributesUsed":FinalAttributeCount,"rowData":sampleRowData,"columnData":finalAttributes,"classifier":"KNN_Classifier","classification":UniqueList,"Precision":precisionKNN,"Filename":Filename}
            return json.dumps(training_result)
    except Exception as err:
        return "Error while Training Model ,stack error {}".format(err)  

#******************************************************************************
#Rename Saved Model
#******************************************************************************


@app.route('/save')    
def rename_savedfile():
    try:
        aliceName = request.args.get('modelName')
        Filename = request.args.get('Filename')
        os.rename(os.path.splitext(Filename)[0]+".sav", aliceName+'.sav')
        return "Done"
    except Exception as err:
        return "Error while Saving Model ,stack error {}".format(err)  
    
    
    


#******************************************************************************
#predicting
#******************************************************************************


@app.route('/dsw/predict', methods=['POST'])   
def predict_result():
    modelName = request.args.get('modelName')
    input_json_sample = request.get_json(force=True)  
    predictData=input_json_sample['rowData']
    classificationData=input_json_sample['Classification']
    precisionData=input_json_sample['Precision']
    saved_model = pickle.load(open(modelName+".sav", 'rb'))
    prediction=saved_model.predict(predictData)
    tempJsonPredict=[]
    count=0
    for data in classificationData:
       tempJsonPredict.append({"classification":str(data),"LikelyResult":precisionData[count]})
       count += 1  
    return json.dumps({"Result": str(prediction[0]),"Likely":tempJsonPredict})

###############################################################################
#Main
###############################################################################

if __name__ == '__main__':
    configuration = Configuration()
    # Configuring Proxies
    configuration.proxies()
    # Strating Server
    app.run('0.0.0.0',1312)
