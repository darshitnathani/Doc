# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 19:26:18 2017

@author: darshit.nj
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


x = np.random.randn(10,1)
y = 2*x+3 + 0.1*np.random.randn(10,1)

plt.scatter(x,y)
plt.show()

model = LinearRegression() 
model.fit(x,y)

print(model.coef_)
print(model.intercept_)

print(model.predict(20))

x_test = np.linspace(-3,3)
y_pred = model.predict(x_test[:,None])

plt.scatter(x,y)
plt.plot(x_test,y_pred,'r')
plt.legend(['Predicted line','Observed data'])
plt.show()