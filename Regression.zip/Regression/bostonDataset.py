# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 15:46:20 2017

@author: darshit.nj
"""

import pandas as pd
import numpy as np
from sklearn import linear_model
from sklearn.cross_validation import train_test_split

from sklearn.datasets import load_boston

bostan_data=load_boston()

print(bostan_data.data)
