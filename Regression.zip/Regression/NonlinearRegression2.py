# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 19:31:39 2017

@author: darshit.nj
"""


import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

x = np.linspace(-5,5,num=100)[:,None]
y = -0.5 + 2.2*x +0.3*x**3+ 2*np.random.randn(100,1)
x_new = np.hstack([x,x**2,x**3,x**4])


plt.plot(x,y)
plt.show()


model = LinearRegression()
model.fit(x_new,y)
print(model.coef_)
print(model.intercept_)
y_pred = model.predict(x_new)
print(y_pred)
plt.scatter(x,y)
plt.plot(x_new[:,0],y_pred,'r')
plt.legend(['Predicted line','Observed data'])
plt.show()

poly = PolynomialFeatures(degree=4,include_bias=False)
x_new2 = poly.fit_transform(x)
print(x_new2)